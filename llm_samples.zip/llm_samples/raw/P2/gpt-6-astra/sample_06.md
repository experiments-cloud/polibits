## Design summary

The current methods couple **type selection**, **object construction**, and **business rules**. Adding a document format or customer category requires changing existing conditional branches.

The refactoring separates these responsibilities:

- **Products:** document exporters and discount policies implement small, typed interfaces.
- **Creators:** abstract creators define factory methods; concrete creators override them to construct the appropriate products. Shared processing methods use those products.
- **Registries:** dictionaries map identifiers to creator classes, providing average **O(1)** lookup. Registration methods support new implementations without modifying the dispatch logic.
- **Compatibility:** `MonolithicSystem` retains its existing public methods, document-format case handling, discount thresholds, fallback behavior, and empty-data handling.

Document output remains the original **simulation**, including its exact formatting. Replacing it with actual PDF generation or changing JSON/XML/CSV escaping would be a separate behavioral change.

## Refactored implementation

```python
# p1_factory_method.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Produce the simulated document representation."""
        raise NotImplementedError


class PdfExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f'{{"data": "{data}"}}'


class XmlExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: concrete subclasses override the Factory Method
# ---------------------------------------------------------------------------

class DocumentCreator(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory Method: subclasses decide which exporter to construct."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PdfDocumentCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return PdfExporter()


class JsonDocumentCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return JsonExporter()


class XmlDocumentCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return XmlExporter()


class CsvDocumentCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return CsvExporter()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Return the final price after applying the policy."""
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VipDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: concrete subclasses override the Factory Method
# ---------------------------------------------------------------------------

class DiscountCreator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory Method: subclasses decide which policy to construct."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VipDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return VipDiscount()


class StudentDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ---------------------------------------------------------------------------
# Existing system facade
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Per-instance registries avoid shared mutable configuration.
        # Store creator classes rather than products so construction remains
        # the responsibility of each concrete Factory Method.
        self._document_creators: dict[str, type[DocumentCreator]] = {
            "pdf": PdfDocumentCreator,
            "json": JsonDocumentCreator,
            "xml": XmlDocumentCreator,
            "csv": CsvDocumentCreator,
        }

        self._discount_creators: dict[str, type[DiscountCreator]] = {
            "REGULAR": RegularDiscountCreator,
            "VIP": VipDiscountCreator,
            "STUDENT": StudentDiscountCreator,
        }

    def register_document_format(
        self,
        format_type: str,
        creator_type: type[DocumentCreator],
    ) -> None:
        """Register or replace a format using a no-argument creator class."""
        self._document_creators[format_type.lower()] = creator_type

    def register_customer_type(
        self,
        customer_type: str,
        creator_type: type[DiscountCreator],
    ) -> None:
        """Register or replace a case-sensitive customer category."""
        self._discount_creators[customer_type] = creator_type

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve the original truthiness check and its precedence:
        # missing data returns this error even for an unsupported format.
        if not data:
            return "Error: No data"

        creator_type = self._document_creators.get(format_type.lower())
        if creator_type is None:
            raise ValueError("Unsupported format")

        return creator_type().process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        # Preserve the original fallback for unknown customer categories.
        creator_type = self._discount_creators.get(
            customer_type,
            NoDiscountCreator,
        )
        return creator_type().calculate(price, items_count)


# ---------------------------------------------------------------------------
# Execution simulation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    system = MonolithicSystem()

    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
```

Run with:

```bash
python3.12 p1_factory_method.py
```

Output:

```text
<PDF Document>Research Report</PDF Document>
1020.0
```

This is **Factory Method**, rather than only a dictionary-based simple factory: the dictionaries select creator classes, while the overridden `create_exporter()` and `create_policy()` methods determine which products the inherited workflows use.