### Design summary

The current methods couple product selection with document formatting and discount rules. Adding a format or customer category therefore requires editing the same conditional structures.

The refactoring separates these responsibilities:

- **Products:** document processors and discount policies implement their respective behavior.
- **Creators:** abstract creators define factory methods; concrete creators override them to instantiate specific products. This is the **Factory Method** pattern, rather than just a dictionary of constructor functions.
- **Registries:** dictionaries select creators with average **O(1)** lookup. Registration methods allow extensions without modifying the existing execution methods.
- **Compatibility:** the public methods, output strings, discount thresholds, case sensitivity, and fallback behavior remain unchanged. Document output remains a simulation; introducing real serialization would change existing behavior.

### Refactored code

```python
# p1_refactored.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentProcessor(ABC):
    @abstractmethod
    def render(self, data: object) -> str:
        """Render data using the document's format."""
        raise NotImplementedError


class PDFProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JSONProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        # Preserve the baseline's simulated serialization.
        return f'{{"data": "{data}"}}'


class XMLProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CSVProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: subclasses override the factory method.
# ---------------------------------------------------------------------------

class DocumentCreator(ABC):
    @abstractmethod
    def create_processor(self) -> DocumentProcessor:
        """Factory Method."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        processor = self.create_processor()
        return processor.render(data)


class PDFCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return PDFProcessor()


class JSONCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return JSONProcessor()


class XMLCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return XMLProcessor()


class CSVCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return CSVProcessor()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Return the price after applying this policy."""
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VIPDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: subclasses override the factory method.
# ---------------------------------------------------------------------------

class DiscountCreator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory Method."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VIPDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return VIPDiscount()


class StudentDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ---------------------------------------------------------------------------
# Existing facade: selects creators and delegates processing.
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Instance-owned registries avoid shared mutable global configuration.
        self._document_creators: dict[str, DocumentCreator] = {
            "pdf": PDFCreator(),
            "json": JSONCreator(),
            "xml": XMLCreator(),
            "csv": CSVCreator(),
        }

        self._discount_creators: dict[str, DiscountCreator] = {
            "REGULAR": RegularDiscountCreator(),
            "VIP": VIPDiscountCreator(),
            "STUDENT": StudentDiscountCreator(),
        }

        self._default_discount_creator: DiscountCreator = NoDiscountCreator()

    def register_document_creator(
        self,
        format_type: str,
        creator: DocumentCreator,
        *,
        replace: bool = False,
    ) -> None:
        """Register an extension, rejecting accidental replacement by default."""
        key = format_type.lower()
        if key in self._document_creators and not replace:
            raise ValueError(f"Document format already registered: {key}")
        self._document_creators[key] = creator

    def register_discount_creator(
        self,
        customer_type: str,
        creator: DiscountCreator,
        *,
        replace: bool = False,
    ) -> None:
        """Customer category keys retain the baseline's case sensitivity."""
        if customer_type in self._discount_creators and not replace:
            raise ValueError(
                f"Customer type already registered: {customer_type}"
            )
        self._discount_creators[customer_type] = creator

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Keep validation before format selection, as in the baseline.
        if not data:
            return "Error: No data"

        creator = self._document_creators.get(format_type.lower())
        if creator is None:
            raise ValueError("Unsupported format")

        return creator.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        creator = self._discount_creators.get(
            customer_type,
            self._default_discount_creator,
        )
        return creator.calculate(price, items_count)


# ---------------------------------------------------------------------------
# Execution simulation and compatibility checks
# ---------------------------------------------------------------------------

def main() -> None:
    system = MonolithicSystem()

    assert system.execute_document_process("PDF", "Report") == (
        "<PDF Document>Report</PDF Document>"
    )
    assert system.execute_document_process("json", "Report") == (
        '{"data": "Report"}'
    )
    assert system.execute_document_process("xml", "Report") == (
        "<xml><data>Report</data></xml>"
    )
    assert system.execute_document_process("csv", "Report") == (
        "header,data\n1,Report"
    )
    assert system.execute_document_process("unsupported", "") == "Error: No data"

    try:
        system.execute_document_process("unsupported", "Report")
    except ValueError as error:
        assert str(error) == "Unsupported format"
    else:
        raise AssertionError("Unsupported formats must raise ValueError")

    assert system.execute_ecommerce_discounts("REGULAR", 100.0, 10) == 100.0
    assert system.execute_ecommerce_discounts("REGULAR", 100.0, 11) == 95.0
    assert system.execute_ecommerce_discounts("VIP", 1000.0, 5) == 900.0
    assert system.execute_ecommerce_discounts("VIP", 1200.0, 5) == 1020.0
    assert system.execute_ecommerce_discounts("STUDENT", 100.0, 1) == 80.0
    assert system.execute_ecommerce_discounts("UNKNOWN", 100.0, 1) == 100.0
    assert system.execute_ecommerce_discounts("vip", 100.0, 1) == 100.0

    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200.0, 5))


if __name__ == "__main__":
    main()
```

Run with:

```bash
python3.12 p1_refactored.py
```

To add a format or discount category, implement its product and concrete creator, then register the creator. Neither execution method needs to change.