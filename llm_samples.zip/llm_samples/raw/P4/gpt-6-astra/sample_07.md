## Design summary

Separate **discount rules** from **strategy selection and execution**:

- **Strategy interface:** An abstract class defines the calculation contract.
- **Concrete strategies:** Each customer category owns its discount rules.
- **Context:** Selects a strategy by name and delegates calculations without knowing discount formulas.
- **Registry:** A dictionary maps names to strategy instances, providing average **O(1)** lookup and allowing new strategies to be registered without modifying selection logic.

Unknown names select a **no-discount strategy**, preserving the baseline behavior. They must not fall back to `REGULAR`, which could incorrectly apply a volume discount.

## Functional implementation

```python
from abc import ABC, abstractmethod


class DiscountStrategy(ABC):
    """Contract implemented by all discount policies."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VipDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects discount policies and delegates price calculations."""

    def __init__(self, strategy_name: str = "REGULAR") -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        # Stateless strategies can be reused for repeated calculations.
        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return name.strip().upper()

    def register_strategy(
        self,
        name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """Register or replace a policy for subsequent selections."""
        self._strategies[self._normalize_name(name)] = strategy

    def set_strategy(self, name: str) -> None:
        """Dynamically select a policy; unknown names mean no discount."""
        self._strategy = self._strategies.get(
            self._normalize_name(name),
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        """Delegate business rules to the currently selected strategy."""
        return self._strategy.calculate(price, items_count)


if __name__ == "__main__":
    from math import isclose

    cart = ShoppingCartContext("VIP")
    total = cart.calculate_total(price=1200.0, items_count=5)
    print(f"VIP total: ${total:.2f}")  # $1020.00

    # Switching policies requires no changes to the calculation workflow.
    cart.set_strategy("REGULAR")
    assert isclose(cart.calculate_total(200.0, 10), 200.0)
    assert isclose(cart.calculate_total(200.0, 11), 190.0)

    cart.set_strategy("VIP")
    assert isclose(cart.calculate_total(1000.0, 5), 900.0)
    assert isclose(cart.calculate_total(1200.0, 5), 1020.0)

    cart.set_strategy("STUDENT")
    assert isclose(cart.calculate_total(200.0, 5), 160.0)

    cart.set_strategy("UNKNOWN")
    assert isclose(cart.calculate_total(200.0, 11), 200.0)

    # Deliberate usability extension: case and whitespace normalization.
    cart.set_strategy(" vip ")
    assert isclose(cart.calculate_total(1200.0, 5), 1020.0)

    print("All checks passed.")
```

## Architectural notes

- **Preserved rules:** Regular customers receive 5% off only above 10 items; VIP customers receive 15% off only above 1000, otherwise 10%; students receive 20%; unknown categories receive no discount.
- **Extensibility:** A future `BlackFridayDiscountStrategy` can be registered under `"BLACK_FRIDAY"` and selected with `set_strategy()`. No rate is invented here because the input specifies no Black Friday rule.
- **Scope:** Document processing remains untouched.
- **Numeric compatibility:** This implementation retains the baseline’s floating-point arithmetic. For production monetary calculations, use `Decimal` throughout the payment pipeline with an explicit currency-rounding policy.
- **Lifecycle:** Because the selected strategy is mutable, use a separate context per cart or request rather than sharing one across concurrent requests.