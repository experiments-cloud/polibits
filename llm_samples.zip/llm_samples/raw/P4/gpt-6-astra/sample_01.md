## Design summary

Separate **discount policy** from **execution**:

- **Strategies** own the business rules: REGULAR, VIP, STUDENT, and no discount.
- **Context** selects a strategy by name and delegates calculation. It contains no discount thresholds or percentages.
- A **dictionary registry** provides average O(1) selection and allows new strategies to be registered without changing the Context.
- Unknown names retain the baseline behavior: **no discount**. Names are normalized to accept inputs such as `" vip "`.
- Use `Decimal` for monetary arithmetic. The implementation does not round results because the original logic specifies no rounding policy.

No BLACK_FRIDAY discount is invented: the supplied system defines none. That name can be registered when its business rule is specified.

## Functional implementation

```python
from abc import ABC, abstractmethod
from decimal import Decimal


class DiscountStrategy(ABC):
    """Contract for calculating the final price."""

    @abstractmethod
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        if items_count > 10:
            return price * Decimal("0.95")
        return price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        multiplier = (
            Decimal("0.85")
            if price > Decimal("1000")
            else Decimal("0.90")
        )
        return price * multiplier


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        return price * Decimal("0.80")


class ShoppingCartContext:
    """Selects and executes a discount policy without owning its rules."""

    def __init__(self, strategy_name: str = "REGULAR") -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()
        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return name.strip().upper()

    def register_strategy(
        self,
        name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """Register or replace a policy for subsequent selections."""
        key = self._normalize_name(name)
        if not key:
            raise ValueError("Strategy name must not be empty.")
        self._strategies[key] = strategy

    def set_strategy(self, name: str) -> None:
        """Dynamically select a policy; unknown names mean no discount."""
        key = self._normalize_name(name)
        self._strategy = self._strategies.get(key, self._fallback)

    def calculate_total(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        """Delegate all pricing decisions to the selected strategy."""
        return self._strategy.calculate(price, items_count)


def verify_behavior() -> None:
    cart = ShoppingCartContext()

    # REGULAR: strictly more than 10 items.
    assert cart.calculate_total(Decimal("100"), 10) == Decimal("100")
    assert cart.calculate_total(Decimal("100"), 11) == Decimal("95")

    # Dynamic selection and name normalization.
    cart.set_strategy(" vip ")

    # VIP: strictly more than 1000 receives the premium discount.
    assert cart.calculate_total(Decimal("1000"), 5) == Decimal("900")
    assert cart.calculate_total(Decimal("1200"), 5) == Decimal("1020")

    cart.set_strategy("STUDENT")
    assert cart.calculate_total(Decimal("100"), 1) == Decimal("80")

    # Preserve the monolith's fallback behavior.
    cart.set_strategy("UNKNOWN")
    assert cart.calculate_total(Decimal("100"), 20) == Decimal("100")


if __name__ == "__main__":
    verify_behavior()

    cart = ShoppingCartContext("VIP")
    total = cart.calculate_total(Decimal("1200"), items_count=5)
    print(f"VIP total: ${total:.2f}")  # VIP total: $1020.00

    cart.set_strategy("REGULAR")
    total = cart.calculate_total(Decimal("1200"), items_count=11)
    print(f"Regular total: ${total:.2f}")  # Regular total: $1140.00
```

### Architectural considerations

- **Extensibility:** Add a `DiscountStrategy` subclass, register its instance, then select it by name. No Context branching needs to change.
- **Testability:** Each policy can be tested independently; Context tests cover selection and delegation.
- **Compatibility:** Discount thresholds and unknown-name behavior are preserved. Intentional API changes are `Decimal` monetary inputs and case-insensitive, whitespace-tolerant selection.
- **Lifecycle:** Strategies are stateless and reusable. The Context has mutable selection state, so use a separate Context per cart or request rather than sharing one across concurrent checkouts.

Document processing remains untouched because it is outside this refactor’s scope.