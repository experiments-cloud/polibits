## Design summary

The refactoring separates two responsibilities:

- **Business rules:** each concrete strategy calculates a discount for one customer type.
- **Execution context:** `ShoppingCartContext` selects a strategy by name and delegates calculation, without knowing discount formulas.

A dictionary is appropriate for selection: it provides average **O(1)** lookup and supports adding strategies without expanding an `if/elif` chain. Because the strategies are stateless, their instances can be reused.

The implementation preserves the original thresholds, case-sensitive names, and fallback behavior: unknown customer types receive no discount. `BLACK_FRIDAY` has no rule in the supplied system, so it also receives no discount unless explicitly registered.

## Functional implementation

```python
# payment_engine.py
# Python 3.10+

from abc import ABC, abstractmethod
from collections.abc import Mapping


class DiscountStrategy(ABC):
    """Contract implemented by every discount rule."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 10 items does not qualify.
        return price * 0.95 if items_count > 10 else price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 1000 receives the standard 10% discount.
        return price * (0.85 if price > 1000 else 0.90)


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects discount strategies and delegates price calculation."""

    def __init__(
        self,
        customer_type: str = "REGULAR",
        additional_strategies: Mapping[str, DiscountStrategy] | None = None,
    ) -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        # Copy entries into our own registry, rather than retaining the
        # caller's mutable mapping. Custom entries may override defaults.
        if additional_strategies is not None:
            self._strategies.update(additional_strategies)

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(customer_type)

    def set_strategy(self, customer_type: str) -> None:
        """Dynamically select a rule; unknown names receive no discount."""
        self._strategy = self._strategies.get(
            customer_type,
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        """Execute the selected rule without interpreting its business logic."""
        return self._strategy.calculate(price, items_count)


def verify_behavior() -> None:
    cart = ShoppingCartContext()

    # REGULAR: volume threshold remains strictly greater than 10.
    assert cart.calculate_total(100.0, 10) == 100.0
    assert cart.calculate_total(100.0, 11) == 95.0

    # Dynamic strategy replacement.
    cart.set_strategy("VIP")
    assert cart.calculate_total(1000.0, 5) == 900.0
    assert cart.calculate_total(1200.0, 5) == 1020.0

    cart.set_strategy("STUDENT")
    assert cart.calculate_total(100.0, 1) == 80.0

    # Preserve the monolith's fallback and case sensitivity.
    for name in ("UNKNOWN", "BLACK_FRIDAY", "vip"):
        cart.set_strategy(name)
        assert cart.calculate_total(100.0, 1) == 100.0


if __name__ == "__main__":
    verify_behavior()

    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(1200.0, 5):.2f}")

    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(1200.0, 11):.2f}")
```

**Output:**
```text
VIP total: $1020.00
Regular total: $1140.00
```

## Architectural implications

- **Extensibility:** introduce a new `DiscountStrategy` subclass and supply it through `additional_strategies`; neither selection nor execution code needs modification.
- **Testability:** each discount rule can be tested independently of the context.
- **Scope:** document processing remains unchanged.
- **Behavioral compatibility:** no new validation, rounding, or discount policies are introduced. This version retains floating-point arithmetic; a production financial system should separately adopt `Decimal` with an explicit currency-rounding policy.