## Design summary

Separate **discount rules** from **strategy selection and execution**:

- **Strategy interface:** an abstract class defines the discount calculation contract.
- **Concrete strategies:** each class owns one customer category’s business rules.
- **Context:** selects a strategy from a dictionary using a normalized text identifier, then delegates calculation. It contains no discount formulas.
- **Fallback:** unknown identifiers select a no-discount strategy, preserving the monolith’s fallback behavior.

A dictionary provides average **O(1)** lookup and supports registering new strategies without changing the context. Strategy instances are reused because they are stateless.

## Functional implementation

```python
from abc import ABC, abstractmethod


class DiscountStrategy(ABC):
    """Contract implemented by all discount rules."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the total price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 10 items do not qualify.
        return price * 0.95 if items_count > 10 else price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 1000 receives the standard VIP discount.
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects and executes discount strategies without owning their rules."""

    def __init__(self, strategy_name: str = "REGULAR") -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize(strategy_name: str) -> str:
        return strategy_name.strip().upper()

    def register_strategy(
        self,
        strategy_name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """Register or replace a strategy for subsequent selections."""
        self._strategies[self._normalize(strategy_name)] = strategy

    def set_strategy(self, strategy_name: str) -> None:
        """Select dynamically; unknown names receive no discount."""
        self._strategy = self._strategies.get(
            self._normalize(strategy_name),
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        """Treat price as the cart total, matching the original implementation."""
        return self._strategy.calculate(price, items_count)


if __name__ == "__main__":
    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(1200.0, 5):.2f}")
    # VIP total: $1020.00

    # Change behavior dynamically on the same context.
    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(200.0, 11):.2f}")
    # Regular total: $190.00

    cart.set_strategy("STUDENT")
    print(f"Student total: ${cart.calculate_total(200.0, 2):.2f}")
    # Student total: $160.00

    cart.set_strategy("UNKNOWN")
    print(f"Fallback total: ${cart.calculate_total(200.0, 11):.2f}")
    # Fallback total: $200.00
```

## Behavioral checks

```python
from math import isclose


def test_discount_rules() -> None:
    cases: list[tuple[str, float, int, float]] = [
        ("REGULAR", 200.0, 10, 200.0),
        ("REGULAR", 200.0, 11, 190.0),
        ("VIP", 1000.0, 5, 900.0),
        ("VIP", 1200.0, 5, 1020.0),
        ("STUDENT", 200.0, 2, 160.0),
        ("UNKNOWN", 200.0, 11, 200.0),
        (" vip ", 1200.0, 5, 1020.0),
    ]

    cart = ShoppingCartContext()

    for name, price, count, expected in cases:
        cart.set_strategy(name)
        assert isclose(cart.calculate_total(price, count), expected)


test_discount_rules()
```

### Architectural notes

- **Extension:** implement another `DiscountStrategy`, register it with `register_strategy("BLACK_FRIDAY", strategy)`, and select it with `set_strategy("BLACK_FRIDAY")`. No Black Friday formula is invented here because the input does not define one; until registered, that identifier receives no discount.
- **Compatibility:** discount formulas and thresholds remain unchanged. Case-insensitive, whitespace-tolerant selection is an intentional usability improvement.
- **Scope:** document processing remains untouched.
- **Money representation:** `float` preserves the baseline’s numeric behavior. A production payment system should adopt `Decimal` with an explicitly agreed currency-rounding policy.
- **Lifecycle:** use one mutable context per cart or request; avoid sharing its active selection across concurrent transactions.