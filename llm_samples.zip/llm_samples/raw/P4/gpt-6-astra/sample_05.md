## Architecture summary

Separate the discount engine into three responsibilities:

- **Strategy interface:** defines how a discount calculates the final price.
- **Concrete strategies:** encapsulate the existing `REGULAR`, `VIP`, and `STUDENT` business rules.
- **Context:** selects a strategy by name and delegates calculation without containing discount rules.

A **dictionary registry** is appropriate for selection: it provides average **O(1)** lookup and allows new strategies to be registered without adding conditional branches to the context. Strategies are stateless, so their instances can be reused.

The implementation preserves the baseline’s thresholds and its **no-discount fallback for unknown names**. It additionally accepts case-insensitive names and surrounding whitespace.

## Functional implementation

```python
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from math import isclose


class DiscountStrategy(ABC):
    """Contract implemented by every discount rule."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying this discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 10 items does not qualify.
        return price * 0.95 if items_count > 10 else price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 1000 receives the standard VIP discount.
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects a discount strategy and delegates price calculation."""

    def __init__(
        self,
        strategy_name: str = "REGULAR",
        additional_strategies: Mapping[str, DiscountStrategy] | None = None,
    ) -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        if additional_strategies is not None:
            for name, strategy in additional_strategies.items():
                self.register_strategy(name, strategy)

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return name.strip().upper()

    def register_strategy(
        self,
        name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """Register or replace a strategy for future selections."""
        self._strategies[self._normalize_name(name)] = strategy

    def set_strategy(self, name: str) -> None:
        """Dynamically select a strategy; unknown names get no discount."""
        self._strategy = self._strategies.get(
            self._normalize_name(name),
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        return self._strategy.calculate(price, items_count)


def verify_baseline_rules() -> None:
    cases: list[tuple[str, float, int, float]] = [
        ("REGULAR", 100.0, 10, 100.0),
        ("REGULAR", 100.0, 11, 95.0),
        ("VIP", 1000.0, 5, 900.0),
        ("VIP", 1200.0, 5, 1020.0),
        ("STUDENT", 100.0, 1, 80.0),
        ("UNKNOWN", 100.0, 20, 100.0),
        (" vip ", 1200.0, 5, 1020.0),
    ]

    cart = ShoppingCartContext()

    for name, price, items_count, expected in cases:
        cart.set_strategy(name)
        actual = cart.calculate_total(price, items_count)
        assert isclose(actual, expected), (
            f"{name}: expected {expected}, got {actual}"
        )


if __name__ == "__main__":
    verify_baseline_rules()

    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(1200.0, 5):.2f}")

    # Change behavior at runtime without replacing the context.
    cart.set_strategy("STUDENT")
    print(f"Student total: ${cart.calculate_total(1200.0, 5):.2f}")

    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(1200.0, 11):.2f}")
```

**Output:**
```text
VIP total: $1020.00
Student total: $960.00
Regular total: $1140.00
```

### Design considerations

- **Extensibility:** a future `BlackFridayDiscountStrategy` can be registered under `"BLACK_FRIDAY"` without modifying the context. No Black Friday rate is invented here because the baseline specifies none.
- **Compatibility:** `price` remains the original amount to discount; it is not multiplied by `items_count`.
- **Numeric behavior:** `float` preserves the baseline’s arithmetic. For production financial settlement, use `Decimal` together with an explicit currency-rounding policy.
- **Scope:** document processing remains unchanged; it is unrelated to discount strategy selection.