## Design summary

The refactor separates **discount rules** from **execution and strategy selection**:

- **Strategy interface:** an abstract class defines how a discount is calculated.
- **Concrete strategies:** each class implements one customer category’s rules.
- **Context:** selects a strategy from a dictionary and delegates the calculation. It contains no discount formulas.
- **Fallback:** unknown categories receive no discount, preserving the monolith’s behavior.

A dictionary is appropriate because selection is an exact key lookup with average **O(1)** complexity. New strategies can be registered without modifying the context’s selection logic.

The implementation uses `Decimal` for monetary calculations. It deliberately leaves rounding to the payment boundary, since the original code defines no rounding policy.

## Functional implementation

```python
from abc import ABC, abstractmethod
from decimal import Decimal


class DiscountStrategy(ABC):
    """Contract implemented by every discount rule."""

    @abstractmethod
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        """Return the discounted total."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        if items_count > 10:
            return price * Decimal("0.95")
        return price


class VipDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        multiplier = (
            Decimal("0.85") if price > Decimal("1000")
            else Decimal("0.90")
        )
        return price * multiplier


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        return price * Decimal("0.80")


class ShoppingCartContext:
    """
    Selects and executes discount strategies.

    Strategies are stateless and can safely be reused by this context.
    The context itself is mutable: use one context per cart/request.
    """

    def __init__(self, strategy_name: str = "REGULAR") -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return name.strip().upper()

    def register_strategy(
        self,
        name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """
        Register or replace a strategy.

        Registration does not change the currently active strategy;
        call set_strategy() to select the registered implementation.
        """
        self._strategies[self._normalize_name(name)] = strategy

    def set_strategy(self, name: str) -> None:
        """Dynamically select a strategy; unknown names get no discount."""
        self._strategy = self._strategies.get(
            self._normalize_name(name),
            self._fallback,
        )

    def calculate_total(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        """Delegate calculation without knowing the discount rules."""
        return self._strategy.calculate(price, items_count)


def verify_baseline_rules() -> None:
    """Check original rules, including their threshold boundaries."""
    cases: list[tuple[str, Decimal, int, Decimal]] = [
        ("REGULAR", Decimal("100"), 10, Decimal("100")),
        ("REGULAR", Decimal("100"), 11, Decimal("95")),
        ("VIP", Decimal("1000"), 5, Decimal("900")),
        ("VIP", Decimal("1200"), 5, Decimal("1020")),
        ("STUDENT", Decimal("100"), 1, Decimal("80")),
        ("UNKNOWN", Decimal("100"), 20, Decimal("100")),
    ]

    cart = ShoppingCartContext()

    for category, price, items_count, expected in cases:
        cart.set_strategy(category)
        actual = cart.calculate_total(price, items_count)
        assert actual == expected, (
            f"{category}: expected {expected}, got {actual}"
        )


if __name__ == "__main__":
    verify_baseline_rules()

    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(Decimal('1200'), 5):.2f}")

    cart.set_strategy("STUDENT")
    print(f"Student total: ${cart.calculate_total(Decimal('1200'), 5):.2f}")

    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(Decimal('1200'), 11):.2f}")
```

**Output:**

```text
VIP total: $1020.00
Student total: $960.00
Regular total: $1140.00
```

## Compatibility and extension notes

- The original thresholds remain unchanged: regular customers need **more than 10 items**, and premium VIP pricing requires **more than 1000**.
- Names are intentionally normalized, so `" vip "` also selects VIP. This is a convenience enhancement over the original case-sensitive matching.
- `BLACK_FRIDAY` has no rule in the supplied code. Until a corresponding strategy is registered, it receives no discount; no promotional rate is invented.
- Construct monetary inputs from strings, such as `Decimal("1200.00")`, rather than binary floats.
- Document processing is outside this refactor and can remain unchanged.