## Design summary

Separate the engine into three responsibilities:

- **Strategies contain business rules:** each customer category implements a common abstract interface.
- **The context coordinates execution:** it selects a strategy and delegates calculation without knowing discount thresholds or percentages.
- **A dictionary acts as the strategy registry:** string-based lookup provides average **O(1)** selection and avoids a growing `if/elif` chain.

The implementation preserves the original discount rules and the fallback of **no discount for unknown categories**. Strategy names are normalized for convenience. Prices use `Decimal` rather than binary floating-point arithmetic; no additional rounding policy is introduced.

## Functional implementation

```python
from abc import ABC, abstractmethod
from decimal import Decimal


class DiscountStrategy(ABC):
    """Contract implemented by every discount rule."""

    @abstractmethod
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        """Return the price after applying this strategy."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        # Original rule: 5% discount only when quantity exceeds 10.
        if items_count > 10:
            return price * Decimal("0.95")
        return price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        # Original rule: exactly 1000 still receives only 10%.
        multiplier = (
            Decimal("0.85")
            if price > Decimal("1000")
            else Decimal("0.90")
        )
        return price * multiplier


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: Decimal, items_count: int) -> Decimal:
        return price * Decimal("0.80")


class ShoppingCartContext:
    """Selects discount behavior and delegates its execution."""

    def __init__(self, strategy_name: str = "REGULAR") -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        # Strategies are stateless, so each instance can be reused.
        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return name.strip().upper()

    def register_strategy(
        self,
        name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """Register or replace a strategy for subsequent selections."""
        self._strategies[self._normalize_name(name)] = strategy

    def set_strategy(self, name: str) -> None:
        """Select behavior dynamically using its registered text name."""
        key = self._normalize_name(name)
        self._strategy = self._strategies.get(key, self._fallback)

    def calculate_total(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        """The context executes the rule without implementing it."""
        return self._strategy.calculate(price, items_count)


def main() -> None:
    cart = ShoppingCartContext("VIP")
    total = cart.calculate_total(Decimal("1200"), items_count=5)
    print(f"VIP total: ${total:.2f}")  # $1020.00

    # Change behavior on the same context at runtime.
    cart.set_strategy(" regular ")
    total = cart.calculate_total(Decimal("200"), items_count=11)
    print(f"Regular total: ${total:.2f}")  # $190.00

    cart.set_strategy("STUDENT")
    total = cart.calculate_total(Decimal("200"), items_count=1)
    print(f"Student total: ${total:.2f}")  # $160.00

    # Unrecognized names preserve the monolith's no-discount fallback.
    cart.set_strategy("UNKNOWN")
    assert cart.calculate_total(Decimal("200"), 1) == Decimal("200")

    # Verify the original threshold boundaries.
    cart.set_strategy("REGULAR")
    assert cart.calculate_total(Decimal("200"), 10) == Decimal("200")
    assert cart.calculate_total(Decimal("200"), 11) == Decimal("190")

    cart.set_strategy("VIP")
    assert cart.calculate_total(Decimal("1000"), 5) == Decimal("900")
    assert cart.calculate_total(Decimal("1200"), 5) == Decimal("1020")


if __name__ == "__main__":
    main()
```

## Architectural considerations

- **Extension without changing selection logic:** implement another `DiscountStrategy`, register it, and select it by name. The context’s execution method remains unchanged.
- **`BLACK_FRIDAY`:** the input defines no rule for this category, so none is invented. Until a corresponding strategy is registered, selecting it produces no discount.
- **Monolith integration:** replace the original discount method with delegation to this context; document processing is outside this refactor’s scope.
- **Concurrency:** the context has mutable selection state. Use one context per cart or request rather than sharing it across concurrent requests.
- **Money input:** construct prices from decimal strings, such as `Decimal("1200.00")`, to avoid importing floating-point approximation.