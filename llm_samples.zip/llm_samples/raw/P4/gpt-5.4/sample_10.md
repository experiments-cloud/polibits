Below is a refactoring of the **discount engine** using the **Strategy** pattern, separating pricing rules from the execution context.

## Architectural reasoning

I’ll separate the monolithic logic into two responsibilities:

1. **Business rules**  
   Each discount rule becomes an independent strategy class:
   - `RegularDiscountStrategy`
   - `VipDiscountStrategy`
   - `StudentDiscountStrategy`
   - `NoDiscountStrategy`

   This removes conditional complexity from the main flow and makes each rule isolated, testable, and extensible.

2. **Execution context**  
   A `ShoppingCartContext` will:
   - hold the active strategy
   - expose a method to dynamically assign the strategy from a string such as `"BLACK_FRIDAY"` or `"REGULAR"`
   - execute the selected strategy against the input data

## Why this design

The monolithic version mixes:
- rule selection
- discount calculation
- fallback behavior

Using Strategy:
- adding a new discount no longer requires changing the calculation flow
- each rule is encapsulated
- the context becomes stable and open for extension

## Data structure and internal algorithm choice

I consider a **dictionary registry** the most appropriate structure inside the `ShoppingCartContext`:

- **O(1)** average lookup by strategy name
- simple normalization via `upper().strip()`
- easy to extend by registering new strategies
- avoids large `if/elif` chains

This is cleaner and more scalable than conditional branching.

---

# Refactored code

```python
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def apply_discount(self, cart: CartData) -> float:
        pass


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR: 5% discount if items_count > 10, otherwise no discount."""

    def apply_discount(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """VIP:
    - 15% discount if price > 1000
    - 10% discount otherwise
    """

    def apply_discount(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT: fixed 20% discount."""

    def apply_discount(self, cart: CartData) -> float:
        return cart.price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """Example extension: BLACK_FRIDAY with fixed 30% discount."""

    def apply_discount(self, cart: CartData) -> float:
        return cart.price * 0.70


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no specific rule is found."""

    def apply_discount(self, cart: CartData) -> float:
        return cart.price


class ShoppingCartContext:
    """
    Context that selects and executes discount strategies.
    """

    def __init__(self) -> None:
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "BLACK_FRIDAY": BlackFridayDiscountStrategy(),
            "DEFAULT": NoDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = self._strategies["DEFAULT"]

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        normalized_name = strategy_name.strip().upper()
        self._strategy = self._strategies.get(
            normalized_name,
            self._strategies["DEFAULT"]
        )

    def register_strategy(self, strategy_name: str, strategy: DiscountStrategy) -> None:
        normalized_name = strategy_name.strip().upper()
        self._strategies[normalized_name] = strategy

    def calculate_final_price(self, price: float, items_count: int) -> float:
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.apply_discount(cart)


if __name__ == "__main__":
    context = ShoppingCartContext()

    # REGULAR
    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR: {context.calculate_final_price(200, 12):.2f}")  # 190.00

    # VIP
    context.set_strategy_by_name("VIP")
    print(f"VIP: {context.calculate_final_price(1200, 5):.2f}")  # 1020.00

    # STUDENT
    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT: {context.calculate_final_price(500, 2):.2f}")  # 400.00

    # BLACK_FRIDAY
    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY: {context.calculate_final_price(500, 2):.2f}")  # 350.00

    # Unknown strategy -> fallback
    context.set_strategy_by_name("UNKNOWN")
    print(f"UNKNOWN: {context.calculate_final_price(500, 2):.2f}")  # 500.00
```

---

## Benefits of this refactoring

- **Open/Closed Principle**: new discount rules can be added without modifying existing calculation logic.
- **Single Responsibility Principle**:
  - strategies handle pricing rules
  - context handles strategy selection and execution
- **Testability**: each strategy can be unit tested independently.
- **Maintainability**: avoids growing `if/elif` structures.

## Suggested next improvement

A natural next step would be to make the context receive the strategy registry by dependency injection, which would improve:
- configurability
- testing
- decoupling from concrete implementations

If you want, I can also provide:
1. a **unit test suite with pytest**, or  
2. a version using **Enum** for safer strategy names.