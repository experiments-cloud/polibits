Below is a refactoring of the **discount/payment engine** using the **Strategy** pattern, separating discount business rules from the execution context.

---

## 1) Separation approach: business rules vs. execution context

I’ll separate the monolithic logic into two responsibilities:

### A. Business rules → Strategy classes
Each discount rule becomes an independent class implementing a common interface:

- `RegularDiscountStrategy`
- `VipDiscountStrategy`
- `StudentDiscountStrategy`
- `NoDiscountStrategy`

This removes `if/elif` discount rules from the main flow and encapsulates each pricing policy in a dedicated unit.

### B. Execution context → `ShoppingCartContext`
The context is responsible for:

- receiving the input data (`price`, `items_count`)
- holding the active strategy
- dynamically selecting the strategy from a text key like `"BLACK_FRIDAY"` or `"REGULAR"`
- delegating price calculation to the selected strategy

### Why this is better
This design improves:

- **Open/Closed Principle**: add a new discount without modifying existing calculation logic
- **Testability**: each strategy can be tested independently
- **Maintainability**: rules are localized and easier to evolve
- **Runtime flexibility**: strategy can be selected dynamically from a string

---

## 2) Refactored functional code with Type Hints and ABC

```python
# payment_engine_strategy.py
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Type


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate_final_price(self, cart: CartData) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no discount applies."""

    def calculate_final_price(self, cart: CartData) -> float:
        return cart.price


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Otherwise no discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Otherwise => 10% discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Fixed 20% discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        return cart.price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    BLACK_FRIDAY:
    - Example extension strategy
    - Fixed 30% discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        return cart.price * 0.70


class ShoppingCartContext:
    """
    Context class that manages strategy selection and execution.
    """

    def __init__(self, strategy: DiscountStrategy | None = None) -> None:
        self._strategy: DiscountStrategy = strategy or NoDiscountStrategy()

        # Dictionary lookup is the most appropriate internal structure here:
        # O(1) average access, scalable, and easy to extend.
        self._strategy_registry: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
            "BLACK_FRIDAY": BlackFridayDiscountStrategy,
            "DEFAULT": NoDiscountStrategy,
        }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        normalized_name = strategy_name.strip().upper()
        strategy_class = self._strategy_registry.get(normalized_name, NoDiscountStrategy)
        self._strategy = strategy_class()

    def calculate_total(self, price: float, items_count: int) -> float:
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.calculate_final_price(cart)


if __name__ == "__main__":
    context = ShoppingCartContext()

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR: {context.calculate_total(200.0, 12):.2f}")  # 190.00

    context.set_strategy_by_name("VIP")
    print(f"VIP: {context.calculate_total(1200.0, 5):.2f}")      # 1020.00

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT: {context.calculate_total(500.0, 2):.2f}")   # 400.00

    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY: {context.calculate_total(500.0, 2):.2f}")  # 350.00

    context.set_strategy_by_name("UNKNOWN")
    print(f"UNKNOWN: {context.calculate_total(500.0, 2):.2f}")   # 500.00
```

---

## 3) Context design with dynamic assignment from text

The requirement asks for a method that dynamically assigns the strategy based on a string such as:

- `"BLACK_FRIDAY"`
- `"REGULAR"`

This is implemented in:

```python
def set_strategy_by_name(self, strategy_name: str) -> None:
    normalized_name = strategy_name.strip().upper()
    strategy_class = self._strategy_registry.get(normalized_name, NoDiscountStrategy)
    self._strategy = strategy_class()
```

### Why this design
I selected a **dictionary registry**:

```python
self._strategy_registry: Dict[str, Type[DiscountStrategy]]
```

because it is the most suitable structure for this case:

- **fast lookup**
- **clear mapping**
- **easy extension**
- avoids another `if/elif` chain, which would reproduce the monolithic problem

---

## 4) Architectural judgment on internal data structure and algorithm

### Chosen structure
A **hash map / dictionary** is the right internal structure for strategy resolution.

### Why not `if/elif`
Because it would keep the strategy selection tightly coupled and less scalable.

### Resolution algorithm
The internal algorithm is:

1. Normalize input with `strip().upper()`
2. Query the registry dictionary
3. Instantiate the mapped strategy
4. Fallback to `NoDiscountStrategy` if not found

This gives:

- **O(1)** average selection time
- centralized registration
- safe behavior for unknown values

---

## Optional improvement: self-registration/factory variant

If you want a more extensible architecture for larger systems, I would recommend separating the registry into a dedicated factory:

```python
class DiscountStrategyFactory:
    _registry: Dict[str, Type[DiscountStrategy]] = {}
```

That would be useful when strategies are loaded from modules/plugins.

---

## Resulting benefits over the monolithic version

Compared to:

```python
def execute_ecommerce_discounts(self, customer_type, price, items_count):
    ...
```

the new design provides:

- isolated discount rules
- cleaner context behavior
- easier addition of new campaigns like `BLACK_FRIDAY`, `CYBER_MONDAY`, etc.
- improved unit testing and maintainability

---

If you want, I can also provide:
1. a **UML class diagram** for this Strategy refactor, or  
2. a version integrated back into the original `MonolithicSystem` as a migration step.