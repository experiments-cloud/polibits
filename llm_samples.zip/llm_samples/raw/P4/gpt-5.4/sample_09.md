Below is a refactor of the **discount/payment engine** using the **Strategy** pattern in Python.

## 1) Separation approach: business rules vs execution context

I’ll separate responsibilities like this:

- **Business rules**: each discount rule becomes an independent strategy class.
  - Example: `RegularDiscountStrategy`, `VipDiscountStrategy`, `StudentDiscountStrategy`.
  - Each class knows only how to calculate the final price for its own rule.
- **Execution context**: a `ShoppingCartContext` orchestrates which strategy to use and when to execute it.
  - It does **not** contain discount formulas.
  - It only resolves a strategy dynamically from a string such as `"BLACK_FRIDAY"` or `"REGULAR"`.

### Why this separation is better
In the monolith, the method `execute_ecommerce_discounts()` mixes:
- selection logic (`if customer_type == ...`)
- pricing algorithm
- execution flow

That makes extension harder. Every new discount requires modifying the same method, increasing risk.

With Strategy:
- adding a new discount means adding a new class
- the context remains stable
- the code follows the **Open/Closed Principle**

## 2) Design judgment for dynamic strategy selection

For the `Context`, the best internal structure is a **dictionary registry**:

```python
dict[str, DiscountStrategy]
```

### Why a dictionary?
- O(1) average lookup time
- simple and explicit
- easy to extend at runtime
- avoids long `if/elif` chains

The context will:
1. normalize the input string (`upper().strip()`)
2. search in the registry
3. assign the proper strategy
4. execute it

I also include:
- a `register_strategy()` method for future extensibility
- a default fallback strategy (`NoDiscountStrategy`) when appropriate

---

# Refactored Code

```python
# strategy_payment_engine.py

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, cart: CartData) -> float:
        """Return final price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy: no discount applied."""

    def calculate(self, cart: CartData) -> float:
        return cart.price


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Otherwise no discount
    """

    def calculate(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Otherwise => 10% discount
    """

    def calculate(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Fixed 20% discount
    """

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    Example of a new strategy requested by dynamic assignment:
    - Flat 30% discount
    """

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.70


class ShoppingCartContext:
    """
    Context responsible for:
    - holding the current strategy
    - resolving strategies dynamically from a text key
    - executing the selected strategy
    """

    def __init__(
        self,
        strategy: Optional[DiscountStrategy] = None,
    ) -> None:
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "BLACK_FRIDAY": BlackFridayDiscountStrategy(),
            "NO_DISCOUNT": NoDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = strategy if strategy is not None else NoDiscountStrategy()

    def register_strategy(self, name: str, strategy: DiscountStrategy) -> None:
        """
        Register a new strategy at runtime.
        """
        normalized_name = self._normalize_key(name)
        self._strategies[normalized_name] = strategy

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """
        Direct strategy injection.
        """
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign a strategy based on a string.
        Example: 'BLACK_FRIDAY', 'REGULAR'.
        """
        normalized_name = self._normalize_key(strategy_name)

        if normalized_name not in self._strategies:
            raise ValueError(f"Unsupported strategy: {strategy_name}")

        self._strategy = self._strategies[normalized_name]

    def calculate_total(self, price: float, items_count: int) -> float:
        """
        Execute the current strategy against the provided cart data.
        """
        self._validate_inputs(price, items_count)
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.calculate(cart)

    @staticmethod
    def _normalize_key(name: str) -> str:
        return name.strip().upper()

    @staticmethod
    def _validate_inputs(price: float, items_count: int) -> None:
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")


if __name__ == "__main__":
    context = ShoppingCartContext()

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR: {context.calculate_total(200.0, 12):.2f}")  # 190.00

    context.set_strategy_by_name("VIP")
    print(f"VIP: {context.calculate_total(1200.0, 5):.2f}")  # 1020.00

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT: {context.calculate_total(300.0, 2):.2f}")  # 240.00

    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY: {context.calculate_total(500.0, 3):.2f}")  # 350.00
```

---

## 3) Architectural notes

### What changed from the monolith
Before:
- one method handled all discount rules
- every new rule required editing a branching block

Now:
- each rule is encapsulated in one strategy class
- `ShoppingCartContext` selects and executes strategies
- dynamic assignment uses a registry map

### Benefits
- **Extensible**: new discounts can be added without modifying existing strategy classes
- **Testable**: each discount can be unit-tested independently
- **Maintainable**: rules are isolated and easier to read
- **Reusable**: strategies can be injected directly or selected by name

---

## 4) Example of adding a new strategy

If later you want a `LOYALTY` strategy:

```python
class LoyaltyDiscountStrategy(DiscountStrategy):
    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.88
```

Then register it:

```python
context.register_strategy("LOYALTY", LoyaltyDiscountStrategy())
context.set_strategy_by_name("LOYALTY")
print(context.calculate_total(250.0, 1))
```

---

## 5) Suggested improvement for production

For real payment engines, I would also recommend:
- using `Decimal` instead of `float` for monetary precision
- adding logging/auditing for selected strategy
- separating pricing DTOs from domain entities
- optionally using a factory if strategy construction becomes more complex

If you want, I can also provide:
1. a **version using `Decimal` for money**, or  
2. a **complete UML/class diagram + unit tests with `pytest`**.