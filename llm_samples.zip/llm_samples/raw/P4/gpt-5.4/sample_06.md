Below is a refactor of the **discount engine** using the **Strategy** behavioral pattern, separating discount rules from the execution context.

## Architectural approach

To separate business rules from the execution context:

1. **Identify volatile business logic**  
   The discount calculation rules vary by customer type:
   - `REGULAR`
   - `VIP`
   - `STUDENT`

   These rules are the most likely to change, so they should not remain embedded in `if/elif` blocks inside the main engine.

2. **Encapsulate each rule in its own strategy**  
   Each discount policy becomes an independent class implementing a common contract:
   - same input
   - same output
   - isolated calculation behavior

3. **Keep the Context focused on orchestration**  
   The `ShoppingCartContext` should:
   - hold the active strategy
   - expose a method to assign the strategy dynamically from a string
   - delegate the calculation to the selected strategy

4. **Use a registry for dynamic selection**  
   Instead of another `if/elif`, the context uses a dictionary:
   - key: strategy name (`"VIP"`, `"REGULAR"`, etc.)
   - value: strategy instance

   This is the most appropriate internal structure here because:
   - lookup is simple and efficient
   - adding a new strategy does not require changing the calculation flow
   - it reduces conditional complexity

---

# Refactored code

```python
# strategy_discount_engine.py
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, cart: CartData) -> float:
        """Return final price after applying the discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR customer discount rules."""

    def calculate(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95  # 5% volume discount
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """VIP customer discount rules."""

    def calculate(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85  # 15% premium VIP discount
        return cart.price * 0.90      # 10% standard VIP discount


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT customer discount rules."""

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.80      # 20% fixed discount


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no known customer type is selected."""

    def calculate(self, cart: CartData) -> float:
        return cart.price


class ShoppingCartContext:
    """
    Context that manages strategy selection and delegates discount execution.
    """

    def __init__(self) -> None:
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "BLACK_FRIDAY": StudentDiscountStrategy(),  # Example dynamic mapping
            "DEFAULT": NoDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = self._strategies["DEFAULT"]

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy directly."""
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign strategy based on a text string.
        Falls back to DEFAULT when the name is unknown.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategy = self._strategies.get(
            normalized_name,
            self._strategies["DEFAULT"]
        )

    def register_strategy(self, strategy_name: str, strategy: DiscountStrategy) -> None:
        """Allow runtime extension of available strategies."""
        normalized_name = strategy_name.strip().upper()
        self._strategies[normalized_name] = strategy

    def calculate_final_price(self, price: float, items_count: int) -> float:
        """Execute the currently assigned discount strategy."""
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.calculate(cart)


# Example of a new strategy added later without changing the Context logic
class BlackFridayDiscountStrategy(DiscountStrategy):
    """BLACK_FRIDAY promotional discount."""

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.70  # 30% discount


if __name__ == "__main__":
    context = ShoppingCartContext()

    # Existing strategies
    context.set_strategy_by_name("VIP")
    print(f"VIP final price: ${context.calculate_final_price(1200, 5):.2f}")

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR final price: ${context.calculate_final_price(500, 12):.2f}")

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT final price: ${context.calculate_final_price(300, 2):.2f}")

    # Runtime extension
    context.register_strategy("BLACK_FRIDAY", BlackFridayDiscountStrategy())
    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY final price: ${context.calculate_final_price(1000, 1):.2f}")

    # Unknown strategy -> fallback
    context.set_strategy_by_name("UNKNOWN")
    print(f"UNKNOWN final price: ${context.calculate_final_price(1000, 1):.2f}")
```

---

## Why this design is better

### 1. Business rules are decoupled
The discount formulas are no longer inside a monolithic method.  
Each pricing rule lives in a dedicated class.

### 2. Better maintainability
To add a new discount type, you create a new strategy class and register it.  
No need to modify core calculation logic.

### 3. Open/Closed Principle
The system is **open for extension** and **closed for modification**.

### 4. Better testability
Each strategy can be unit tested independently:
- `VipDiscountStrategy`
- `RegularDiscountStrategy`
- `StudentDiscountStrategy`

### 5. Cleaner Context behavior
The `ShoppingCartContext` does not know the internals of each business rule.  
It only selects and executes the active strategy.

---

## Mapping from monolithic code to Strategy design

Original monolithic logic:

```python
if customer_type == "REGULAR":
    ...
elif customer_type == "VIP":
    ...
elif customer_type == "STUDENT":
    ...
else:
    ...
```

Refactored design:
- `RegularDiscountStrategy`
- `VipDiscountStrategy`
- `StudentDiscountStrategy`
- `NoDiscountStrategy`

The decision structure is replaced by **polymorphism**.

---

## Optional improvement

If you want stronger typing for valid names, you could replace plain strings with an `Enum`, while still keeping `set_strategy_by_name()` for external integration.

If you want, I can also provide:
1. a **unit test suite with pytest**, or  
2. a version that uses **Enum + factory registry**, which is even more robust for production systems.