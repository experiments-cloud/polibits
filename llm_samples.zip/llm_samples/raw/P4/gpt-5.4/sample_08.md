Below is a refactoring of the **discount/payment engine** using the **Strategy** pattern, separating the discount business rules from the execution context.

---

## 1) Architectural reasoning: separating business rules from execution context

I’ll keep this at a high level and implementation-oriented.

### Problem in the monolith
In `execute_ecommerce_discounts`, the system mixes:

- **execution flow**
- **strategy selection**
- **business discount rules**

inside a single method with `if/elif` branches.

This creates tight coupling:
- adding a new discount type requires editing the method
- testing rules independently is harder
- the method grows over time and violates the Open/Closed Principle

---

### Refactoring approach with Strategy
To separate concerns:

#### A. Business rules → Strategy classes
Each discount rule becomes its own class:
- `RegularDiscountStrategy`
- `VipDiscountStrategy`
- `StudentDiscountStrategy`
- `NoDiscountStrategy`

Each class implements a common abstract contract:
- `calculate(price, items_count) -> float`

This isolates the rule logic.

---

#### B. Execution context → `ShoppingCartContext`
The context is responsible for:
- holding the active strategy
- selecting a strategy dynamically from a string such as `"BLACK_FRIDAY"` or `"REGULAR"`
- delegating the final calculation to the selected strategy

The context should **not** know the internals of each business rule. It only orchestrates.

---

### Why a dictionary-based strategy registry?
For dynamic selection by text string, the most appropriate internal structure is a registry:

```python
Dict[str, Type[DiscountStrategy]]
```

Why this is a good fit:
- **O(1)** average lookup
- cleaner than large `if/elif`
- easy to extend by registering new strategies
- centralizes supported strategy names
- allows runtime reassignment

This is better than a chain of conditionals because selection becomes data-driven.

---

## 2) Functional Python code with Type Hints and ABC

```python
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Type


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return final price after applying the strategy."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no discount applies."""

    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Else => no discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Else => 10% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Always 20% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    Example additional strategy:
    - Always 30% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.70


@dataclass
class ShoppingCartContext:
    """
    Context responsible for:
    - maintaining the active discount strategy
    - selecting a strategy dynamically from a string
    - delegating discount calculation
    """

    strategy: DiscountStrategy = field(default_factory=NoDiscountStrategy)

    def __post_init__(self) -> None:
        self._strategy_registry: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
            "BLACK_FRIDAY": BlackFridayDiscountStrategy,
            "NONE": NoDiscountStrategy,
        }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy instance directly."""
        self.strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign a strategy from a text string.

        Raises:
            ValueError: if the strategy name is unsupported.
        """
        normalized_name = strategy_name.strip().upper()
        strategy_class = self._strategy_registry.get(normalized_name)

        if strategy_class is None:
            supported = ", ".join(sorted(self._strategy_registry.keys()))
            raise ValueError(
                f"Unsupported strategy '{strategy_name}'. Supported strategies: {supported}"
            )

        self.strategy = strategy_class()

    def register_strategy(
        self,
        strategy_name: str,
        strategy_class: Type[DiscountStrategy],
    ) -> None:
        """
        Allow future extension without modifying selection logic.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategy_registry[normalized_name] = strategy_class

    def calculate_final_price(self, price: float, items_count: int) -> float:
        """
        Execute the selected strategy.

        Raises:
            ValueError: if price or items_count are invalid.
        """
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")

        return self.strategy.calculate(price, items_count)
```

---

## 3) Example usage

```python
if __name__ == "__main__":
    cart = ShoppingCartContext()

    cart.set_strategy_by_name("REGULAR")
    print(f"REGULAR => {cart.calculate_final_price(200.0, 12):.2f}")  # 190.00

    cart.set_strategy_by_name("VIP")
    print(f"VIP => {cart.calculate_final_price(1200.0, 5):.2f}")      # 1020.00

    cart.set_strategy_by_name("STUDENT")
    print(f"STUDENT => {cart.calculate_final_price(300.0, 2):.2f}")   # 240.00

    cart.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY => {cart.calculate_final_price(500.0, 1):.2f}")  # 350.00

    cart.set_strategy_by_name("NONE")
    print(f"NONE => {cart.calculate_final_price(500.0, 1):.2f}")      # 500.00
```

---

## 4) Refactored version preserving the original monolithic behavior

If you want a class that mirrors the original system but delegates discount processing to the Strategy-based engine:

```python
from __future__ import annotations

class RefactoredSystem:
    def __init__(self) -> None:
        self.version = "2.0 - Strategy Pattern"
        self.cart_context = ShoppingCartContext()

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Kept as-is from baseline for scope isolation."""
        if not data:
            return "Error: No data"

        normalized = format_type.lower()

        if normalized == "pdf":
            return f"<PDF Document>{data}</PDF Document>"
        elif normalized == "json":
            return f"{{\"data\": \"{data}\"}}"
        elif normalized == "xml":
            return f"<xml><data>{data}</data></xml>"
        elif normalized == "csv":
            return f"header,data\n1,{data}"
        else:
            raise ValueError("Unsupported format")

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """
        Refactored discount execution using Strategy pattern.
        """
        self.cart_context.set_strategy_by_name(customer_type)
        return self.cart_context.calculate_final_price(price, items_count)
```

Usage:

```python
if __name__ == "__main__":
    system = RefactoredSystem()
    system.execute_document_process("pdf", "Research Report")
    final_price = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"Final price: ${final_price:.2f}")
```

---

## 5) Benefits of this design

### Before
- one method handled all discount logic
- adding a strategy meant modifying existing code
- harder to unit test each rule separately

### After
- each rule is encapsulated in its own class
- the context only coordinates strategy selection and execution
- strategy selection is efficient via registry dictionary
- new strategies can be added with minimal changes
- easier testing and maintenance

---

## 6) Extension example: adding a new strategy
To add `LOYALTY` without touching the selection algorithm:

```python
class LoyaltyDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.88


cart = ShoppingCartContext()
cart.register_strategy("LOYALTY", LoyaltyDiscountStrategy)
cart.set_strategy_by_name("LOYALTY")
print(cart.calculate_final_price(1000.0, 3))  # 880.0
```

---

## 7) Final architectural note
The key separation is:

- **Strategy classes** = discount rules / business behavior
- **ShoppingCartContext** = runtime execution and strategy orchestration

This keeps the engine extensible, testable, and aligned with the **Strategy behavioral design pattern**.

If you want, I can also provide:
1. **unit tests with `pytest`**, or  
2. a **UML class diagram** for this refactoring.