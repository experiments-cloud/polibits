To refactor the payment engine using the 'Strategy' design pattern, we will separate the business rules (discount logic) from the execution context. This will allow us to dynamically select and apply different discount strategies based on the customer type. Here's how we can achieve this:

### Chain of Thought

1. **Identify the Business Logic**: The discount logic is currently embedded within the `execute_ecommerce_discounts` method. We need to extract this logic into separate strategy classes.

2. **Define an Abstract Strategy**: We'll create an abstract base class `DiscountStrategy` that defines a method `calculate_discount` which each concrete strategy will implement.

3. **Implement Concrete Strategies**: For each customer type (`REGULAR`, `VIP`, `STUDENT`), we'll create a concrete class that implements the `DiscountStrategy` interface.

4. **Create a Context Class**: We'll design a `ShoppingCartContext` class that will hold a reference to a `DiscountStrategy` object. This class will have a method to dynamically assign the strategy based on a string identifier.

5. **Refactor the Execution Method**: The `execute_ecommerce_discounts` method will be refactored to use the `ShoppingCartContext` to apply the appropriate discount strategy.

### Refactored Code

```python
from abc import ABC, abstractmethod
from typing import Dict, Type

# Abstract Strategy
class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float, items_count: int) -> float:
        pass

# Concrete Strategies
class RegularDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% Volume discount
        return price

class VIPDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% Premium VIP discount
        return price * 0.90  # 10% Standard VIP discount

class StudentDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% Fixed discount

class NoDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price

# Context Class
class ShoppingCartContext:
    def __init__(self):
        self._strategy: DiscountStrategy = NoDiscountStrategy()
        self._strategies: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VIPDiscountStrategy,
            "STUDENT": StudentDiscountStrategy
        }

    def set_strategy(self, customer_type: str):
        strategy_class = self._strategies.get(customer_type.upper(), NoDiscountStrategy)
        self._strategy = strategy_class()

    def calculate_final_price(self, price: float, items_count: int) -> float:
        return self._strategy.calculate_discount(price, items_count)

# Refactored Monolithic System
class MonolithicSystem:
    def __init__(self):
        self.version = "2.0 - Refactored"
        self.cart_context = ShoppingCartContext()

    def execute_document_process(self, format_type, data):
        """Document Processing logic remains unchanged."""
        if not data:
            return "Error: No data"
        
        if format_type.lower() == "pdf":
            result = f"<PDF Document>{data}</PDF Document>"
        elif format_type.lower() == "json":
            result = f"{{\"data\": \"{data}\"}}"
        elif format_type.lower() == "xml":
            result = f"<xml><data>{data}</data></xml>"
        elif format_type.lower() == "csv":
            result = f"header,data\n1,{data}"
        else:
            raise ValueError("Unsupported format")
            
        return result

    def execute_ecommerce_discounts(self, customer_type, price, items_count):
        """Refactored Discount Engine using Strategy Pattern."""
        self.cart_context.set_strategy(customer_type)
        final_price = self.cart_context.calculate_final_price(price, items_count)
        return final_price

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
```

### Explanation

- **Abstract Strategy**: `DiscountStrategy` defines the interface for all discount strategies.
- **Concrete Strategies**: Each customer type has its own strategy class implementing the discount logic.
- **Context Class**: `ShoppingCartContext` manages the strategy selection and applies the selected strategy.
- **Dynamic Strategy Assignment**: The `set_strategy` method in `ShoppingCartContext` allows dynamic assignment of strategies based on the customer type string.
- **Refactored System**: The `MonolithicSystem` now uses the `ShoppingCartContext` to handle discount calculations, making the system more modular and maintainable.