To refactor the payment engine using the Strategy design pattern, we will separate the business rules (discount logic) from the execution context. This involves creating a set of strategy classes that encapsulate the discount logic for different customer types. The `ShoppingCartContext` class will be responsible for selecting and applying the appropriate strategy based on the customer type.

### Chain of Thought

1. **Identify the Business Rules**: The discount logic for different customer types (`REGULAR`, `VIP`, `STUDENT`) is the core business rule that needs to be separated from the execution context.

2. **Define Strategy Interface**: We'll create an abstract base class `DiscountStrategy` that defines a method `calculate_discount` which each concrete strategy will implement.

3. **Implement Concrete Strategies**: For each customer type, we'll implement a concrete strategy class that inherits from `DiscountStrategy` and implements the discount logic.

4. **Design Context Class**: The `ShoppingCartContext` class will hold a reference to a `DiscountStrategy` object. It will include a method to dynamically assign the strategy based on a string identifier (e.g., 'REGULAR', 'VIP', 'STUDENT').

5. **Dynamic Strategy Assignment**: The context class will use a dictionary to map string identifiers to strategy classes, allowing for dynamic assignment of the discount strategy.

6. **Refactor Execution Logic**: The `execute_ecommerce_discounts` method will be refactored to use the `ShoppingCartContext` to apply the appropriate discount strategy.

### Refactored Code

```python
from abc import ABC, abstractmethod
from typing import Type

# Define the Strategy Interface
class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float, items_count: int) -> float:
        pass

# Concrete Strategy for Regular Customers
class RegularDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% Volume discount
        return price

# Concrete Strategy for VIP Customers
class VIPDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% Premium VIP discount
        return price * 0.90  # 10% Standard VIP discount

# Concrete Strategy for Student Customers
class StudentDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% Fixed discount

# Context Class
class ShoppingCartContext:
    def __init__(self):
        self._strategy: DiscountStrategy = None

    def set_strategy(self, customer_type: str) -> None:
        strategies: dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VIPDiscountStrategy,
            "STUDENT": StudentDiscountStrategy
        }
        strategy_class = strategies.get(customer_type.upper())
        if not strategy_class:
            raise ValueError(f"Unsupported customer type: {customer_type}")
        self._strategy = strategy_class()

    def calculate_final_price(self, price: float, items_count: int) -> float:
        if not self._strategy:
            raise RuntimeError("Strategy not set")
        return self._strategy.calculate_discount(price, items_count)

# Refactored Execution
if __name__ == "__main__":
    cart_context = ShoppingCartContext()
    cart_context.set_strategy("VIP")
    final_price = cart_context.calculate_final_price(1200, 5)
    print(f"Final price: ${final_price:.2f}")
```

### Explanation

- **Strategy Interface**: `DiscountStrategy` is an abstract base class that defines the `calculate_discount` method.
- **Concrete Strategies**: Each customer type has a corresponding strategy class that implements the discount logic.
- **Context Class**: `ShoppingCartContext` manages the strategy and provides a method to set the strategy based on a string identifier.
- **Dynamic Strategy Assignment**: The `set_strategy` method uses a dictionary to map customer types to strategy classes, allowing for easy extension and maintenance.

This refactoring separates the business logic from the execution context, making the system more modular and easier to maintain.