To refactor the payment engine using the Strategy design pattern, we will separate the business rules (discount logic) from the execution context. This involves creating a set of strategy classes that encapsulate the discount logic for different customer types. The `ShoppingCartContext` class will be responsible for selecting and applying the appropriate discount strategy based on the customer type.

### Chain of Thought

1. **Identify the Business Rules**: The discount logic is currently embedded within the `execute_ecommerce_discounts` method. We need to extract this logic into separate classes.

2. **Define Strategy Interface**: We'll create an abstract base class `DiscountStrategy` that defines a method `calculate_discount` which each concrete strategy will implement.

3. **Implement Concrete Strategies**: For each customer type (`REGULAR`, `VIP`, `STUDENT`), we'll create a concrete class that implements the `DiscountStrategy` interface.

4. **Create Context Class**: The `ShoppingCartContext` class will hold a reference to a `DiscountStrategy` object. It will include a method to dynamically assign the strategy based on a string identifier.

5. **Refactor Execution Logic**: The `execute_ecommerce_discounts` method will be refactored to use the `ShoppingCartContext` to apply the appropriate discount strategy.

### Refactored Code

```python
from abc import ABC, abstractmethod
from typing import Dict, Type

# Define the Strategy interface
class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float, items_count: int) -> float:
        pass

# Concrete Strategy for Regular customers
class RegularDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% Volume discount
        return price

# Concrete Strategy for VIP customers
class VIPDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% Premium VIP discount
        return price * 0.90  # 10% Standard VIP discount

# Concrete Strategy for Student customers
class StudentDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% Fixed discount

# Context class to use the strategy
class ShoppingCartContext:
    def __init__(self):
        self._strategy: DiscountStrategy = None
        self._strategies: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VIPDiscountStrategy,
            "STUDENT": StudentDiscountStrategy
        }

    def set_strategy(self, customer_type: str):
        strategy_class = self._strategies.get(customer_type.upper())
        if not strategy_class:
            raise ValueError(f"Unsupported customer type: {customer_type}")
        self._strategy = strategy_class()

    def calculate_final_price(self, price: float, items_count: int) -> float:
        if not self._strategy:
            raise ValueError("Strategy not set")
        return self._strategy.calculate_discount(price, items_count)

# Refactored MonolithicSystem class
class MonolithicSystem:
    def __init__(self):
        self.version = "2.0 - Refactored"
        self.cart_context = ShoppingCartContext()

    def execute_document_process(self, format_type, data):
        """Document Processing logic remains unchanged."""
        if not data:
            return "Error: No data"
        
        if format_type.lower() == "pdf":
            result = f"<PDF Document>{data}</PDF Document>"
        elif format_type.lower() == "json":
            result = f"{{\"data\": \"{data}\"}}"
        elif format_type.lower() == "xml":
            result = f"<xml><data>{data}</data></xml>"
        elif format_type.lower() == "csv":
            result = f"header,data\n1,{data}"
        else:
            raise ValueError("Unsupported format")
            
        return result

    def execute_ecommerce_discounts(self, customer_type, price, items_count):
        """Refactored Discount Engine using Strategy Pattern."""
        self.cart_context.set_strategy(customer_type)
        final_price = self.cart_context.calculate_final_price(price, items_count)
        return final_price

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
```

### Explanation

- **Strategy Interface**: `DiscountStrategy` is an abstract base class that defines the `calculate_discount` method.
- **Concrete Strategies**: Each customer type has its own class implementing the `DiscountStrategy` interface.
- **Context Class**: `ShoppingCartContext` manages the strategy selection and application. It uses a dictionary to map customer types to their respective strategy classes.
- **MonolithicSystem**: The `execute_ecommerce_discounts` method now uses the `ShoppingCartContext` to apply the appropriate discount strategy.