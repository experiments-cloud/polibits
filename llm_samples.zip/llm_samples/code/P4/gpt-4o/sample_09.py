# Extracted automatically from sample_09.md by generate_samples.py (fenced:1)
from abc import ABC, abstractmethod
from typing import Dict, Type

# Abstract Strategy
class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float, items_count: int) -> float:
        pass

# Concrete Strategies
class RegularDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% Volume discount
        return price

class VIPDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% Premium VIP discount
        return price * 0.90  # 10% Standard VIP discount

class StudentDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% Fixed discount

class NoDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price

# Context Class
class ShoppingCartContext:
    def __init__(self):
        self._strategy: DiscountStrategy = NoDiscountStrategy()
        self._strategies: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VIPDiscountStrategy,
            "STUDENT": StudentDiscountStrategy
        }

    def set_strategy(self, customer_type: str):
        strategy_class = self._strategies.get(customer_type.upper(), NoDiscountStrategy)
        self._strategy = strategy_class()

    def calculate_final_price(self, price: float, items_count: int) -> float:
        return self._strategy.calculate_discount(price, items_count)

# Refactored Monolithic System
class MonolithicSystem:
    def __init__(self):
        self.version = "2.0 - Refactored"
        self.cart_context = ShoppingCartContext()

    def execute_document_process(self, format_type, data):
        """Document Processing logic remains unchanged."""
        if not data:
            return "Error: No data"
        
        if format_type.lower() == "pdf":
            result = f"<PDF Document>{data}</PDF Document>"
        elif format_type.lower() == "json":
            result = f"{{\"data\": \"{data}\"}}"
        elif format_type.lower() == "xml":
            result = f"<xml><data>{data}</data></xml>"
        elif format_type.lower() == "csv":
            result = f"header,data\n1,{data}"
        else:
            raise ValueError("Unsupported format")
            
        return result

    def execute_ecommerce_discounts(self, customer_type, price, items_count):
        """Refactored Discount Engine using Strategy Pattern."""
        self.cart_context.set_strategy(customer_type)
        final_price = self.cart_context.calculate_final_price(price, items_count)
        return final_price

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
