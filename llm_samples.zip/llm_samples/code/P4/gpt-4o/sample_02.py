# Extracted automatically from sample_02.md by generate_samples.py (fenced:1)
from abc import ABC, abstractmethod
from typing import Type

# Define the Strategy Interface
class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float, items_count: int) -> float:
        pass

# Concrete Strategy for Regular Customers
class RegularDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% Volume discount
        return price

# Concrete Strategy for VIP Customers
class VIPDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% Premium VIP discount
        return price * 0.90  # 10% Standard VIP discount

# Concrete Strategy for Student Customers
class StudentDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% Fixed discount

# Context Class
class ShoppingCartContext:
    def __init__(self):
        self._strategy: DiscountStrategy = None

    def set_strategy(self, customer_type: str) -> None:
        strategies: dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VIPDiscountStrategy,
            "STUDENT": StudentDiscountStrategy
        }
        strategy_class = strategies.get(customer_type.upper())
        if not strategy_class:
            raise ValueError(f"Unsupported customer type: {customer_type}")
        self._strategy = strategy_class()

    def calculate_final_price(self, price: float, items_count: int) -> float:
        if not self._strategy:
            raise RuntimeError("Strategy not set")
        return self._strategy.calculate_discount(price, items_count)

# Refactored Execution
if __name__ == "__main__":
    cart_context = ShoppingCartContext()
    cart_context.set_strategy("VIP")
    final_price = cart_context.calculate_final_price(1200, 5)
    print(f"Final price: ${final_price:.2f}")
