# Extracted automatically from sample_05.md by generate_samples.py (fenced:1)
from abc import ABC, abstractmethod
from typing import Dict, Type

# Define the Strategy interface
class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float, items_count: int) -> float:
        pass

# Concrete Strategy for Regular customers
class RegularDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% Volume discount
        return price

# Concrete Strategy for VIP customers
class VIPDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% Premium VIP discount
        return price * 0.90  # 10% Standard VIP discount

# Concrete Strategy for Student customers
class StudentDiscountStrategy(DiscountStrategy):
    def calculate_discount(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% Fixed discount

# Context class to use the strategy
class ShoppingCartContext:
    def __init__(self):
        self._strategy: DiscountStrategy = None
        self._strategies: Dict[str, Type[DiscountStrategy]] = {
            'REGULAR': RegularDiscountStrategy,
            'VIP': VIPDiscountStrategy,
            'STUDENT': StudentDiscountStrategy
        }

    def set_strategy(self, customer_type: str):
        strategy_class = self._strategies.get(customer_type.upper())
        if not strategy_class:
            raise ValueError(f"Unsupported customer type: {customer_type}")
        self._strategy = strategy_class()

    def calculate_final_price(self, price: float, items_count: int) -> float:
        if not self._strategy:
            raise ValueError("Strategy not set")
        return self._strategy.calculate_discount(price, items_count)

# Refactored MonolithicSystem class
class MonolithicSystem:
    def __init__(self):
        self.version = "2.0 - Refactored"
        self.cart_context = ShoppingCartContext()

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        self.cart_context.set_strategy(customer_type)
        final_price = self.cart_context.calculate_final_price(price, items_count)
        return final_price

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    final_price = system.execute_ecommerce_discounts("VIP", 1200, 5)
    print(f"Final price: ${final_price:.2f}")
