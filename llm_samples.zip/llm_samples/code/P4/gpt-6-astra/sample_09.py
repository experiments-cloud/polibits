# Extracted automatically from sample_09.md by generate_samples.py (fenced:2)
# payment_engine.py
from abc import ABC, abstractmethod
from decimal import Decimal
from typing import Mapping, Optional


class DiscountStrategy(ABC):
    """Contract implemented by every discount rule."""

    @abstractmethod
    def calculate_final_price(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        """Return the price after applying this strategy."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate_final_price(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate_final_price(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        # Exactly 10 items does not qualify.
        if items_count > 10:
            return price * Decimal("0.95")
        return price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate_final_price(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        # Exactly 1000 receives the standard 10% discount.
        multiplier = (
            Decimal("0.85")
            if price > Decimal("1000")
            else Decimal("0.90")
        )
        return price * multiplier


class StudentDiscountStrategy(DiscountStrategy):
    def calculate_final_price(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        return price * Decimal("0.80")


class ShoppingCartContext:
    """Selects and executes a discount strategy.

    Unknown category names intentionally select the no-discount strategy.
    Additional strategies can be supplied without changing this class.
    """

    def __init__(
        self,
        customer_type: str = "REGULAR",
        additional_strategies: Optional[
            Mapping[str, DiscountStrategy]
        ] = None,
    ) -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        if additional_strategies is not None:
            # Copy entries into our registry rather than retaining the
            # caller's mutable mapping. Explicit overrides are supported.
            self._strategies.update(additional_strategies)

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(customer_type)

    def set_strategy(self, customer_type: str) -> None:
        """Dynamically select the active strategy by its exact name."""
        self._strategy = self._strategies.get(
            customer_type,
            self._fallback,
        )

    def calculate_total(
        self,
        price: Decimal,
        items_count: int,
    ) -> Decimal:
        """Delegate business-rule execution to the active strategy."""
        return self._strategy.calculate_final_price(price, items_count)


def main() -> None:
    cart = ShoppingCartContext("VIP")

    total = cart.calculate_total(Decimal("1200"), items_count=5)
    assert total == Decimal("1020")
    print(f"VIP total: ${total:.2f}")

    # Change behavior at runtime on the same context.
    cart.set_strategy("REGULAR")
    assert cart.calculate_total(Decimal("200"), 10) == Decimal("200")
    assert cart.calculate_total(Decimal("200"), 11) == Decimal("190")

    cart.set_strategy("VIP")
    assert cart.calculate_total(Decimal("1000"), 5) == Decimal("900")
    assert cart.calculate_total(Decimal("1200"), 5) == Decimal("1020")

    cart.set_strategy("STUDENT")
    assert cart.calculate_total(Decimal("200"), 5) == Decimal("160")

    # Preserve the original fallback behavior.
    cart.set_strategy("UNKNOWN")
    assert cart.calculate_total(Decimal("200"), 5) == Decimal("200")

    print("All discount checks passed.")


if __name__ == "__main__":
    main()
