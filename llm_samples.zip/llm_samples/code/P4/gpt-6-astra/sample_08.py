# Extracted automatically from sample_08.md by generate_samples.py (fenced:1)
from abc import ABC, abstractmethod
from collections.abc import Mapping
from math import isclose


class DiscountStrategy(ABC):
    """Contract implemented by every discount rule."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying this strategy."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 10 items does not qualify.
        return price * 0.95 if items_count > 10 else price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 1000 receives the standard VIP discount.
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects a discount strategy and delegates price calculation."""

    def __init__(
        self,
        strategy_name: str = "REGULAR",
        additional_strategies: Mapping[str, DiscountStrategy] | None = None,
    ) -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        # Stateless strategy instances can be reused across calculations.
        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        # Copy entries into a context-owned registry.
        # Explicitly supplied entries may also override built-in names.
        if additional_strategies is not None:
            self._strategies.update(additional_strategies)

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    def set_strategy(self, strategy_name: str) -> None:
        """Dynamically select a strategy; unknown names mean no discount."""
        self._strategy = self._strategies.get(
            strategy_name,
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        return self._strategy.calculate(price, items_count)


def verify_behavior() -> None:
    """Check baseline rules, boundaries, and runtime switching."""
    cart = ShoppingCartContext()

    cases: list[tuple[str, float, int, float]] = [
        ("REGULAR", 100.0, 10, 100.0),
        ("REGULAR", 100.0, 11, 95.0),
        ("VIP", 1000.0, 5, 900.0),
        ("VIP", 1200.0, 5, 1020.0),
        ("STUDENT", 100.0, 1, 80.0),
        ("UNKNOWN", 100.0, 20, 100.0),
    ]

    for name, price, items_count, expected in cases:
        cart.set_strategy(name)
        actual = cart.calculate_total(price, items_count)
        assert isclose(actual, expected), (
            f"{name}: expected {expected}, received {actual}"
        )


if __name__ == "__main__":
    verify_behavior()

    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(1200.0, 5):.2f}")

    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(1200.0, 11):.2f}")
