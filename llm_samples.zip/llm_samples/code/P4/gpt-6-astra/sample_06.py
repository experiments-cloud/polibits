# Extracted automatically from sample_06.md by generate_samples.py (fenced:2)
from abc import ABC, abstractmethod


class DiscountStrategy(ABC):
    """Contract implemented by all discount rules."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the total price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 10 items do not qualify.
        return price * 0.95 if items_count > 10 else price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 1000 receives the standard VIP discount.
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects and executes discount strategies without owning their rules."""

    def __init__(self, strategy_name: str = "REGULAR") -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(strategy_name)

    @staticmethod
    def _normalize(strategy_name: str) -> str:
        return strategy_name.strip().upper()

    def register_strategy(
        self,
        strategy_name: str,
        strategy: DiscountStrategy,
    ) -> None:
        """Register or replace a strategy for subsequent selections."""
        self._strategies[self._normalize(strategy_name)] = strategy

    def set_strategy(self, strategy_name: str) -> None:
        """Select dynamically; unknown names receive no discount."""
        self._strategy = self._strategies.get(
            self._normalize(strategy_name),
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        """Treat price as the cart total, matching the original implementation."""
        return self._strategy.calculate(price, items_count)


if __name__ == "__main__":
    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(1200.0, 5):.2f}")
    # VIP total: $1020.00

    # Change behavior dynamically on the same context.
    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(200.0, 11):.2f}")
    # Regular total: $190.00

    cart.set_strategy("STUDENT")
    print(f"Student total: ${cart.calculate_total(200.0, 2):.2f}")
    # Student total: $160.00

    cart.set_strategy("UNKNOWN")
    print(f"Fallback total: ${cart.calculate_total(200.0, 11):.2f}")
    # Fallback total: $200.00
