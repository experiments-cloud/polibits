# Extracted automatically from sample_03.md by generate_samples.py (fenced:1)
from abc import ABC, abstractmethod
from collections.abc import Mapping


class DiscountStrategy(ABC):
    """Contract implemented by every discount policy."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying this policy."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Strictly more than 10 items qualifies.
        return price * 0.95 if items_count > 10 else price


class VIPDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        # Exactly 1000 receives the standard VIP discount.
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class ShoppingCartContext:
    """Selects discount policies and delegates their execution."""

    def __init__(
        self,
        customer_type: str = "REGULAR",
        strategies: Mapping[str, DiscountStrategy] | None = None,
    ) -> None:
        self._fallback: DiscountStrategy = NoDiscountStrategy()

        self._strategies: dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VIPDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
        }

        # Copy entries rather than retaining the caller's mutable mapping.
        # Supplied entries can extend or override the default policies.
        if strategies is not None:
            self._strategies.update(strategies)

        self._strategy: DiscountStrategy = self._fallback
        self.set_strategy(customer_type)

    def set_strategy(self, customer_type: str) -> None:
        """Dynamically select a policy using its text identifier."""
        self._strategy = self._strategies.get(
            customer_type,
            self._fallback,
        )

    def calculate_total(self, price: float, items_count: int) -> float:
        """Execute the currently selected policy."""
        return self._strategy.calculate(price, items_count)


def verify_baseline_behavior() -> None:
    """Check the original rules, boundaries, and fallback behavior."""
    from math import isclose

    cases: list[tuple[str, float, int, float]] = [
        ("REGULAR", 100.0, 10, 100.0),
        ("REGULAR", 100.0, 11, 95.0),
        ("VIP", 1000.0, 5, 900.0),
        ("VIP", 1200.0, 5, 1020.0),
        ("STUDENT", 100.0, 1, 80.0),
        ("UNKNOWN", 100.0, 20, 100.0),
        ("vip", 100.0, 5, 100.0),  # Case-sensitive, as before.
    ]

    cart = ShoppingCartContext()

    for customer_type, price, items_count, expected in cases:
        cart.set_strategy(customer_type)
        actual = cart.calculate_total(price, items_count)
        assert isclose(actual, expected), (
            f"{customer_type}: expected {expected}, got {actual}"
        )


if __name__ == "__main__":
    verify_baseline_behavior()

    cart = ShoppingCartContext("VIP")
    print(f"VIP total: ${cart.calculate_total(1200.0, 5):.2f}")

    # Change behavior without recreating the context.
    cart.set_strategy("REGULAR")
    print(f"Regular total: ${cart.calculate_total(1200.0, 11):.2f}")
