# Extracted automatically from sample_02.md by generate_samples.py (fenced:8)
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate_final_price(self, price: float, items_count: int) -> float:
        """Calculate final price after applying strategy rules."""
        pass


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR customer:
    - 5% discount if items_count > 10
    - otherwise no discount
    """

    def calculate_final_price(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    """VIP customer:
    - 15% discount if price > 1000
    - otherwise 10% discount
    """

    def calculate_final_price(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT customer:
    - fixed 20% discount
    """

    def calculate_final_price(self, price: float, items_count: int) -> float:
        return price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """BLACK_FRIDAY example:
    - fixed 30% discount
    """

    def calculate_final_price(self, price: float, items_count: int) -> float:
        return price * 0.70


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no known rule is found."""

    def calculate_final_price(self, price: float, items_count: int) -> float:
        return price


@dataclass
class ShoppingCartContext:
    """Context responsible for:
    - holding the current strategy
    - dynamically selecting strategies by string key
    - delegating price calculation
    """

    _strategies: Dict[str, DiscountStrategy] = field(default_factory=dict)
    _current_strategy: DiscountStrategy = field(default_factory=NoDiscountStrategy)

    def __post_init__(self) -> None:
        if not self._strategies:
            self._strategies = {
                "REGULAR": RegularDiscountStrategy(),
                "VIP": VipDiscountStrategy(),
                "STUDENT": StudentDiscountStrategy(),
                "BLACK_FRIDAY": BlackFridayDiscountStrategy(),
            }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy directly."""
        self._current_strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """Assign strategy dynamically using a text key."""
        normalized_name = strategy_name.strip().upper()
        self._current_strategy = self._strategies.get(normalized_name, NoDiscountStrategy())

    def register_strategy(self, strategy_name: str, strategy: DiscountStrategy) -> None:
        """Allow runtime extension of supported strategies."""
        normalized_name = strategy_name.strip().upper()
        self._strategies[normalized_name] = strategy

    def calculate_total(self, price: float, items_count: int) -> float:
        """Delegate the calculation to the selected strategy."""
        self._validate_inputs(price, items_count)
        return self._current_strategy.calculate_final_price(price, items_count)

    @staticmethod
    def _validate_inputs(price: float, items_count: int) -> None:
        if price < 0:
            raise ValueError("Price cannot be negative.")
        if items_count < 0:
            raise ValueError("Items count cannot be negative.")
