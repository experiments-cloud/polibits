# Extracted automatically from sample_05.md by generate_samples.py (fenced:2)
# strategy_payment_engine.py

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Type


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def apply_discount(self, cart: CartData) -> float:
        """Return final price after applying the discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR customer:
    - 5% discount if items_count > 10
    - otherwise no discount
    """

    def apply_discount(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """VIP customer:
    - 15% discount if price > 1000
    - otherwise 10% discount
    """

    def apply_discount(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT customer:
    - fixed 20% discount
    """

    def apply_discount(self, cart: CartData) -> float:
        return cart.price * 0.80


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy for unknown or default cases."""

    def apply_discount(self, cart: CartData) -> float:
        return cart.price


class ShoppingCartContext:
    """Context that selects and executes a discount strategy."""

    def __init__(self, strategy: DiscountStrategy | None = None) -> None:
        self._strategy: DiscountStrategy = strategy or NoDiscountStrategy()

        # Registry chosen as a dictionary for fast lookup and easy extensibility.
        self._strategy_registry: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
            "BLACK_FRIDAY": StudentDiscountStrategy,  # Example alias if needed
            "NONE": NoDiscountStrategy,
        }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy instance directly."""
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """Assign strategy dynamically from a text key."""
        normalized_name = strategy_name.strip().upper()

        strategy_class = self._strategy_registry.get(normalized_name)
        if strategy_class is None:
            self._strategy = NoDiscountStrategy()
            return

        self._strategy = strategy_class()

    def register_strategy(
        self,
        strategy_name: str,
        strategy_class: Type[DiscountStrategy],
    ) -> None:
        """Allow runtime extension of available strategies."""
        self._strategy_registry[strategy_name.strip().upper()] = strategy_class

    def calculate_final_price(self, price: float, items_count: int) -> float:
        """Execute the currently selected strategy."""
        self._validate_input(price=price, items_count=items_count)
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.apply_discount(cart)

    @staticmethod
    def _validate_input(price: float, items_count: int) -> None:
        if price < 0:
            raise ValueError("Price cannot be negative.")
        if items_count < 0:
            raise ValueError("Items count cannot be negative.")


# Example custom strategy
class BlackFridayDiscountStrategy(DiscountStrategy):
    """Example:
    - 30% fixed discount for Black Friday
    """

    def apply_discount(self, cart: CartData) -> float:
        return cart.price * 0.70


if __name__ == "__main__":
    context = ShoppingCartContext()

    # Dynamic assignment by string
    context.set_strategy_by_name("VIP")
    print(f"VIP final price: {context.calculate_final_price(1200, 5):.2f}")

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR final price: {context.calculate_final_price(500, 12):.2f}")

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT final price: {context.calculate_final_price(300, 2):.2f}")

    # Register a new strategy at runtime
    context.register_strategy("BLACK_FRIDAY", BlackFridayDiscountStrategy)
    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY final price: {context.calculate_final_price(1000, 1):.2f}")

    # Unknown strategy -> fallback
    context.set_strategy_by_name("UNKNOWN")
    print(f"UNKNOWN final price: {context.calculate_final_price(200, 1):.2f}")
