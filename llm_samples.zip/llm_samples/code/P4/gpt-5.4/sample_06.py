# Extracted automatically from sample_06.md by generate_samples.py (fenced:2)
# strategy_discount_engine.py
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, cart: CartData) -> float:
        """Return final price after applying the discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR customer discount rules."""

    def calculate(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95  # 5% volume discount
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """VIP customer discount rules."""

    def calculate(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85  # 15% premium VIP discount
        return cart.price * 0.90      # 10% standard VIP discount


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT customer discount rules."""

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.80      # 20% fixed discount


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no known customer type is selected."""

    def calculate(self, cart: CartData) -> float:
        return cart.price


class ShoppingCartContext:
    """
    Context that manages strategy selection and delegates discount execution.
    """

    def __init__(self) -> None:
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "BLACK_FRIDAY": StudentDiscountStrategy(),  # Example dynamic mapping
            "DEFAULT": NoDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = self._strategies["DEFAULT"]

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy directly."""
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign strategy based on a text string.
        Falls back to DEFAULT when the name is unknown.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategy = self._strategies.get(
            normalized_name,
            self._strategies["DEFAULT"]
        )

    def register_strategy(self, strategy_name: str, strategy: DiscountStrategy) -> None:
        """Allow runtime extension of available strategies."""
        normalized_name = strategy_name.strip().upper()
        self._strategies[normalized_name] = strategy

    def calculate_final_price(self, price: float, items_count: int) -> float:
        """Execute the currently assigned discount strategy."""
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.calculate(cart)


# Example of a new strategy added later without changing the Context logic
class BlackFridayDiscountStrategy(DiscountStrategy):
    """BLACK_FRIDAY promotional discount."""

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.70  # 30% discount


if __name__ == "__main__":
    context = ShoppingCartContext()

    # Existing strategies
    context.set_strategy_by_name("VIP")
    print(f"VIP final price: ${context.calculate_final_price(1200, 5):.2f}")

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR final price: ${context.calculate_final_price(500, 12):.2f}")

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT final price: ${context.calculate_final_price(300, 2):.2f}")

    # Runtime extension
    context.register_strategy("BLACK_FRIDAY", BlackFridayDiscountStrategy())
    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY final price: ${context.calculate_final_price(1000, 1):.2f}")

    # Unknown strategy -> fallback
    context.set_strategy_by_name("UNKNOWN")
    print(f"UNKNOWN final price: ${context.calculate_final_price(1000, 1):.2f}")
