# Extracted automatically from sample_01.md by generate_samples.py (fenced:8)
# strategy_discount_engine.py
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR customer:
    - 5% discount if items_count > 10
    - otherwise no discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    """VIP customer:
    - 15% discount if price > 1000
    - otherwise 10% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT customer:
    - fixed 20% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no customer type matches."""

    def calculate(self, price: float, items_count: int) -> float:
        return price


@dataclass
class ShoppingCartContext:
    """Execution context for selecting and applying discount strategies."""

    _strategies: Dict[str, DiscountStrategy]
    _strategy: DiscountStrategy

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy directly."""
        self._strategy = strategy

    def set_strategy_by_name(self, customer_type: str) -> None:
        """Assign a strategy dynamically based on a text key."""
        normalized_key = customer_type.strip().upper()
        self._strategy = self._strategies.get(normalized_key, NoDiscountStrategy())

    def calculate_total(self, price: float, items_count: int) -> float:
        """Delegate discount calculation to the active strategy."""
        self._validate_inputs(price, items_count)
        return self._strategy.calculate(price, items_count)

    def register_strategy(self, name: str, strategy: DiscountStrategy) -> None:
        """Allow runtime registration of new strategies."""
        normalized_key = name.strip().upper()
        self._strategies[normalized_key] = strategy

    @staticmethod
    def _validate_inputs(price: float, items_count: int) -> None:
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")


def build_shopping_cart_context() -> ShoppingCartContext:
    """Factory/helper to create a context with default strategies."""
    strategies: Dict[str, DiscountStrategy] = {
        "REGULAR": RegularDiscountStrategy(),
        "VIP": VipDiscountStrategy(),
        "STUDENT": StudentDiscountStrategy(),
    }

    return ShoppingCartContext(
        _strategies=strategies,
        _strategy=NoDiscountStrategy(),
    )


# Example usage
if __name__ == "__main__":
    cart = build_shopping_cart_context()

    examples = [
        ("REGULAR", 200.0, 12),
        ("VIP", 1200.0, 5),
        ("STUDENT", 300.0, 2),
        ("UNKNOWN", 150.0, 1),
    ]

    for customer_type, price, items_count in examples:
        cart.set_strategy_by_name(customer_type)
        final_price = cart.calculate_total(price, items_count)
        print(
            f"Customer: {customer_type:8} | "
            f"Price: {price:8.2f} | "
            f"Items: {items_count:2d} | "
            f"Final: {final_price:8.2f}"
        )
