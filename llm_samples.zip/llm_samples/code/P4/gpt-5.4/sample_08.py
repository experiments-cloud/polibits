# Extracted automatically from sample_08.md by generate_samples.py (fenced:6)
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Type


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return final price after applying the strategy."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no discount applies."""

    def calculate(self, price: float, items_count: int) -> float:
        return price


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Else => no discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Else => 10% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Always 20% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    Example additional strategy:
    - Always 30% discount
    """

    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.70


@dataclass
class ShoppingCartContext:
    """
    Context responsible for:
    - maintaining the active discount strategy
    - selecting a strategy dynamically from a string
    - delegating discount calculation
    """

    strategy: DiscountStrategy = field(default_factory=NoDiscountStrategy)

    def __post_init__(self) -> None:
        self._strategy_registry: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
            "BLACK_FRIDAY": BlackFridayDiscountStrategy,
            "NONE": NoDiscountStrategy,
        }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy instance directly."""
        self.strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign a strategy from a text string.

        Raises:
            ValueError: if the strategy name is unsupported.
        """
        normalized_name = strategy_name.strip().upper()
        strategy_class = self._strategy_registry.get(normalized_name)

        if strategy_class is None:
            supported = ", ".join(sorted(self._strategy_registry.keys()))
            raise ValueError(
                f"Unsupported strategy '{strategy_name}'. Supported strategies: {supported}"
            )

        self.strategy = strategy_class()

    def register_strategy(
        self,
        strategy_name: str,
        strategy_class: Type[DiscountStrategy],
    ) -> None:
        """
        Allow future extension without modifying selection logic.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategy_registry[normalized_name] = strategy_class

    def calculate_final_price(self, price: float, items_count: int) -> float:
        """
        Execute the selected strategy.

        Raises:
            ValueError: if price or items_count are invalid.
        """
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")

        return self.strategy.calculate(price, items_count)
