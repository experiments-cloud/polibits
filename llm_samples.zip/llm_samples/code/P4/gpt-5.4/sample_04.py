# Extracted automatically from sample_04.md by generate_samples.py (fenced:5)
# payment_engine_strategy.py
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Type


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate_final_price(self, cart: CartData) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no discount applies."""

    def calculate_final_price(self, cart: CartData) -> float:
        return cart.price


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Otherwise no discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Otherwise => 10% discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Fixed 20% discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        return cart.price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    BLACK_FRIDAY:
    - Example extension strategy
    - Fixed 30% discount
    """

    def calculate_final_price(self, cart: CartData) -> float:
        return cart.price * 0.70


class ShoppingCartContext:
    """
    Context class that manages strategy selection and execution.
    """

    def __init__(self, strategy: DiscountStrategy | None = None) -> None:
        self._strategy: DiscountStrategy = strategy or NoDiscountStrategy()

        # Dictionary lookup is the most appropriate internal structure here:
        # O(1) average access, scalable, and easy to extend.
        self._strategy_registry: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
            "BLACK_FRIDAY": BlackFridayDiscountStrategy,
            "DEFAULT": NoDiscountStrategy,
        }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        normalized_name = strategy_name.strip().upper()
        strategy_class = self._strategy_registry.get(normalized_name, NoDiscountStrategy)
        self._strategy = strategy_class()

    def calculate_total(self, price: float, items_count: int) -> float:
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.calculate_final_price(cart)


if __name__ == "__main__":
    context = ShoppingCartContext()

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR: {context.calculate_total(200.0, 12):.2f}")  # 190.00

    context.set_strategy_by_name("VIP")
    print(f"VIP: {context.calculate_total(1200.0, 5):.2f}")      # 1020.00

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT: {context.calculate_total(500.0, 2):.2f}")   # 400.00

    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY: {context.calculate_total(500.0, 2):.2f}")  # 350.00

    context.set_strategy_by_name("UNKNOWN")
    print(f"UNKNOWN: {context.calculate_total(500.0, 2):.2f}")   # 500.00
