# Extracted automatically from sample_03.md by generate_samples.py (fenced:4)
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict


class DiscountStrategy(ABC):
    """Strategy interface for discount calculation."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    """REGULAR customer discount logic."""

    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% volume discount
        return price


class VipDiscountStrategy(DiscountStrategy):
    """VIP customer discount logic."""

    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% premium VIP discount
        return price * 0.90      # 10% standard VIP discount


class StudentDiscountStrategy(DiscountStrategy):
    """STUDENT customer discount logic."""

    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80  # 20% fixed discount


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy when no specific discount applies."""

    def calculate(self, price: float, items_count: int) -> float:
        return price


class ShoppingCartContext:
    """
    Context responsible for selecting and executing discount strategies.
    """

    def __init__(self) -> None:
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "DEFAULT": NoDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = self._strategies["DEFAULT"]

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Assign a strategy directly."""
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign the strategy based on a text string.
        Falls back to DEFAULT if the provided key is not registered.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategy = self._strategies.get(
            normalized_name,
            self._strategies["DEFAULT"]
        )

    def register_strategy(self, name: str, strategy: DiscountStrategy) -> None:
        """Allow runtime registration of new strategies."""
        normalized_name = name.strip().upper()
        self._strategies[normalized_name] = strategy

    def calculate_total(self, price: float, items_count: int) -> float:
        """Delegate the discount calculation to the current strategy."""
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")

        return self._strategy.calculate(price, items_count)


class PaymentEngine:
    """
    Application service that uses the ShoppingCartContext
    to calculate the final payable amount.
    """

    def __init__(self, cart_context: ShoppingCartContext) -> None:
        self._cart_context = cart_context

    def process_payment(
        self,
        customer_type: str,
        price: float,
        items_count: int
    ) -> float:
        self._cart_context.set_strategy_by_name(customer_type)
        return self._cart_context.calculate_total(price, items_count)


if __name__ == "__main__":
    context = ShoppingCartContext()
    engine = PaymentEngine(context)

    scenarios = [
        ("REGULAR", 200.0, 12),
        ("VIP", 1200.0, 5),
        ("VIP", 500.0, 2),
        ("STUDENT", 300.0, 1),
        ("UNKNOWN", 150.0, 3),
    ]

    for customer_type, price, items_count in scenarios:
        final_price = engine.process_payment(customer_type, price, items_count)
        print(
            f"Customer={customer_type:8} | "
            f"Price={price:8.2f} | "
            f"Items={items_count:2d} | "
            f"Final={final_price:8.2f}"
        )
