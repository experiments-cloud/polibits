# Extracted automatically from sample_07.md by generate_samples.py (fenced:6)
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def apply_discount(self, cart: CartData) -> float:
        """Return final price after applying the discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Otherwise no discount
    """

    def apply_discount(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Otherwise => 10% discount
    """

    def apply_discount(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Fixed 20% discount
    """

    def apply_discount(self, cart: CartData) -> float:
        return cart.price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    BLACK_FRIDAY:
    - Example rule: fixed 30% discount
    """

    def apply_discount(self, cart: CartData) -> float:
        return cart.price * 0.70


class NoDiscountStrategy(DiscountStrategy):
    """
    Fallback strategy:
    - No discount applied
    """

    def apply_discount(self, cart: CartData) -> float:
        return cart.price


class ShoppingCartContext:
    """
    Context responsible for:
    - selecting the proper discount strategy
    - executing the selected strategy
    """

    def __init__(self) -> None:
        self._strategy: DiscountStrategy = NoDiscountStrategy()
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "BLACK_FRIDAY": BlackFridayDiscountStrategy(),
        }

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """Manually assign a concrete strategy."""
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign a strategy based on a text string.
        Unknown strategies fall back to NoDiscountStrategy.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategy = self._strategies.get(normalized_name, NoDiscountStrategy())

    def calculate_total(self, price: float, items_count: int) -> float:
        """
        Execute the currently selected strategy.
        """
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")

        cart = CartData(price=price, items_count=items_count)
        return self._strategy.apply_discount(cart)

    def register_strategy(self, strategy_name: str, strategy: DiscountStrategy) -> None:
        """
        Optional extension point to register new strategies at runtime.
        """
        normalized_name = strategy_name.strip().upper()
        self._strategies[normalized_name] = strategy


class PaymentEngine:
    """
    Application service that uses ShoppingCartContext
    to calculate the payable amount.
    """

    def __init__(self, context: ShoppingCartContext) -> None:
        self._context = context

    def process_payment(self, customer_type: str, price: float, items_count: int) -> float:
        self._context.set_strategy_by_name(customer_type)
        final_price = self._context.calculate_total(price, items_count)
        return final_price


if __name__ == "__main__":
    context = ShoppingCartContext()
    engine = PaymentEngine(context)

    samples = [
        ("REGULAR", 500.0, 12),
        ("VIP", 1200.0, 5),
        ("VIP", 800.0, 2),
        ("STUDENT", 300.0, 1),
        ("BLACK_FRIDAY", 1000.0, 3),
        ("UNKNOWN", 250.0, 4),
    ]

    for customer_type, price, items_count in samples:
        final_price = engine.process_payment(customer_type, price, items_count)
        print(
            f"CustomerType={customer_type:<13} "
            f"Price={price:>8.2f} "
            f"Items={items_count:>2} "
            f"Final={final_price:>8.2f}"
        )
