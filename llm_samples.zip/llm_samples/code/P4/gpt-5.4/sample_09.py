# Extracted automatically from sample_09.md by generate_samples.py (fenced:4)
# strategy_payment_engine.py

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass(frozen=True)
class CartData:
    price: float
    items_count: int


class DiscountStrategy(ABC):
    """Abstract strategy for discount calculation."""

    @abstractmethod
    def calculate(self, cart: CartData) -> float:
        """Return final price after applying the discount."""
        raise NotImplementedError


class NoDiscountStrategy(DiscountStrategy):
    """Fallback strategy: no discount applied."""

    def calculate(self, cart: CartData) -> float:
        return cart.price


class RegularDiscountStrategy(DiscountStrategy):
    """
    REGULAR:
    - If items_count > 10 => 5% discount
    - Otherwise no discount
    """

    def calculate(self, cart: CartData) -> float:
        if cart.items_count > 10:
            return cart.price * 0.95
        return cart.price


class VipDiscountStrategy(DiscountStrategy):
    """
    VIP:
    - If price > 1000 => 15% discount
    - Otherwise => 10% discount
    """

    def calculate(self, cart: CartData) -> float:
        if cart.price > 1000:
            return cart.price * 0.85
        return cart.price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    """
    STUDENT:
    - Fixed 20% discount
    """

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.80


class BlackFridayDiscountStrategy(DiscountStrategy):
    """
    Example of a new strategy requested by dynamic assignment:
    - Flat 30% discount
    """

    def calculate(self, cart: CartData) -> float:
        return cart.price * 0.70


class ShoppingCartContext:
    """
    Context responsible for:
    - holding the current strategy
    - resolving strategies dynamically from a text key
    - executing the selected strategy
    """

    def __init__(
        self,
        strategy: Optional[DiscountStrategy] = None,
    ) -> None:
        self._strategies: Dict[str, DiscountStrategy] = {
            "REGULAR": RegularDiscountStrategy(),
            "VIP": VipDiscountStrategy(),
            "STUDENT": StudentDiscountStrategy(),
            "BLACK_FRIDAY": BlackFridayDiscountStrategy(),
            "NO_DISCOUNT": NoDiscountStrategy(),
        }
        self._strategy: DiscountStrategy = strategy if strategy is not None else NoDiscountStrategy()

    def register_strategy(self, name: str, strategy: DiscountStrategy) -> None:
        """
        Register a new strategy at runtime.
        """
        normalized_name = self._normalize_key(name)
        self._strategies[normalized_name] = strategy

    def set_strategy(self, strategy: DiscountStrategy) -> None:
        """
        Direct strategy injection.
        """
        self._strategy = strategy

    def set_strategy_by_name(self, strategy_name: str) -> None:
        """
        Dynamically assign a strategy based on a string.
        Example: 'BLACK_FRIDAY', 'REGULAR'.
        """
        normalized_name = self._normalize_key(strategy_name)

        if normalized_name not in self._strategies:
            raise ValueError(f"Unsupported strategy: {strategy_name}")

        self._strategy = self._strategies[normalized_name]

    def calculate_total(self, price: float, items_count: int) -> float:
        """
        Execute the current strategy against the provided cart data.
        """
        self._validate_inputs(price, items_count)
        cart = CartData(price=price, items_count=items_count)
        return self._strategy.calculate(cart)

    @staticmethod
    def _normalize_key(name: str) -> str:
        return name.strip().upper()

    @staticmethod
    def _validate_inputs(price: float, items_count: int) -> None:
        if price < 0:
            raise ValueError("Price cannot be negative")
        if items_count < 0:
            raise ValueError("Items count cannot be negative")


if __name__ == "__main__":
    context = ShoppingCartContext()

    context.set_strategy_by_name("REGULAR")
    print(f"REGULAR: {context.calculate_total(200.0, 12):.2f}")  # 190.00

    context.set_strategy_by_name("VIP")
    print(f"VIP: {context.calculate_total(1200.0, 5):.2f}")  # 1020.00

    context.set_strategy_by_name("STUDENT")
    print(f"STUDENT: {context.calculate_total(300.0, 2):.2f}")  # 240.00

    context.set_strategy_by_name("BLACK_FRIDAY")
    print(f"BLACK_FRIDAY: {context.calculate_total(500.0, 3):.2f}")  # 350.00
