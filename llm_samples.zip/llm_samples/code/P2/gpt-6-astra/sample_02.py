# Extracted automatically from sample_02.md by generate_samples.py (fenced:1)
# p1_refactored.py
# Python 3.12 — standard library only.

from abc import ABC, abstractmethod


# ============================================================
# Document products
# ============================================================

class Document(ABC):
    @abstractmethod
    def render(self, data: object) -> str:
        """Render data using the document's format."""
        ...


class PDFDocument(Document):
    def render(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JSONDocument(Document):
    def render(self, data: object) -> str:
        return f'{{"data": "{data}"}}'


class XMLDocument(Document):
    def render(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CSVDocument(Document):
    def render(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ============================================================
# Document creators
# ============================================================

class DocumentCreator(ABC):
    @abstractmethod
    def create_document(self) -> Document:
        """Factory Method implemented by concrete creators."""
        ...

    def process(self, data: object) -> str:
        document = self.create_document()
        return document.render(data)


class PDFDocumentCreator(DocumentCreator):
    def create_document(self) -> Document:
        return PDFDocument()


class JSONDocumentCreator(DocumentCreator):
    def create_document(self) -> Document:
        return JSONDocument()


class XMLDocumentCreator(DocumentCreator):
    def create_document(self) -> Document:
        return XMLDocument()


class CSVDocumentCreator(DocumentCreator):
    def create_document(self) -> Document:
        return CSVDocument()


# ============================================================
# Discount products
# ============================================================

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price."""
        ...


class RegularDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VIPDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ============================================================
# Discount creators
# ============================================================

class DiscountCreator(ABC):
    @abstractmethod
    def create_discount(self) -> DiscountPolicy:
        """Factory Method implemented by concrete creators."""
        ...

    def calculate(self, price: float, items_count: int) -> float:
        discount = self.create_discount()
        return discount.apply(price, items_count)


class RegularDiscountCreator(DiscountCreator):
    def create_discount(self) -> DiscountPolicy:
        return RegularDiscount()


class VIPDiscountCreator(DiscountCreator):
    def create_discount(self) -> DiscountPolicy:
        return VIPDiscount()


class StudentDiscountCreator(DiscountCreator):
    def create_discount(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCreator(DiscountCreator):
    def create_discount(self) -> DiscountPolicy:
        return NoDiscount()


# ============================================================
# Existing public facade
# ============================================================

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Creator instances are stateless and reusable.
        # Products are instantiated through their Factory Methods.
        self._document_creators: dict[str, DocumentCreator] = {
            "pdf": PDFDocumentCreator(),
            "json": JSONDocumentCreator(),
            "xml": XMLDocumentCreator(),
            "csv": CSVDocumentCreator(),
        }

        self._discount_creators: dict[str, DiscountCreator] = {
            "REGULAR": RegularDiscountCreator(),
            "VIP": VIPDiscountCreator(),
            "STUDENT": StudentDiscountCreator(),
        }

        self._default_discount_creator: DiscountCreator = (
            NoDiscountCreator()
        )

    def register_document_creator(
        self,
        format_type: str,
        creator: DocumentCreator,
    ) -> None:
        """Register a format without silently replacing an existing one."""
        key = format_type.lower()
        if key in self._document_creators:
            raise ValueError(f"Document format already registered: {key}")
        self._document_creators[key] = creator

    def register_discount_creator(
        self,
        customer_type: str,
        creator: DiscountCreator,
    ) -> None:
        """Register a case-sensitive customer category."""
        if customer_type in self._discount_creators:
            raise ValueError(
                f"Customer type already registered: {customer_type}"
            )
        self._discount_creators[customer_type] = creator

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Keep validation before dispatch: even an unsupported format
        # returns this error when the data is empty, as in the baseline.
        if not data:
            return "Error: No data"

        creator = self._document_creators.get(format_type.lower())
        if creator is None:
            raise ValueError("Unsupported format")

        return creator.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        creator = self._discount_creators.get(
            customer_type,
            self._default_discount_creator,
        )
        return creator.calculate(price, items_count)


# ============================================================
# Executable compatibility checks and demonstration
# ============================================================

def verify_compatibility(system: MonolithicSystem) -> None:
    assert system.execute_document_process("PDF", "Report") == (
        "<PDF Document>Report</PDF Document>"
    )
    assert system.execute_document_process("json", "Report") == (
        '{"data": "Report"}'
    )
    assert system.execute_document_process("xml", "Report") == (
        "<xml><data>Report</data></xml>"
    )
    assert system.execute_document_process("csv", "Report") == (
        "header,data\n1,Report"
    )
    assert system.execute_document_process("unknown", "") == "Error: No data"

    try:
        system.execute_document_process("unknown", "Report")
    except ValueError as error:
        assert str(error) == "Unsupported format"
    else:
        raise AssertionError("Unsupported formats must raise ValueError")

    assert system.execute_ecommerce_discounts("REGULAR", 100.0, 10) == 100.0
    assert system.execute_ecommerce_discounts("REGULAR", 100.0, 11) == 95.0
    assert system.execute_ecommerce_discounts("VIP", 1000.0, 1) == 900.0
    assert system.execute_ecommerce_discounts("VIP", 1200.0, 5) == 1020.0
    assert system.execute_ecommerce_discounts("STUDENT", 100.0, 1) == 80.0
    assert system.execute_ecommerce_discounts("UNKNOWN", 100.0, 1) == 100.0
    assert system.execute_ecommerce_discounts("vip", 100.0, 1) == 100.0


if __name__ == "__main__":
    system = MonolithicSystem()
    verify_compatibility(system)

    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200.0, 5))
