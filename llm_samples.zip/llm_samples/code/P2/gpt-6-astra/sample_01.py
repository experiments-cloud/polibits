# Extracted automatically from sample_01.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Produce the document representation."""
        raise NotImplementedError


class PDFExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JSONExporter(DocumentExporter):
    def export(self, data: object) -> str:
        # Preserve the baseline's string representation.
        return f'{{"data": "{data}"}}'


class XMLExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CSVExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: subclasses implement the Factory Method
# ---------------------------------------------------------------------------

class DocumentProcessor(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory Method: concrete processors choose the exporter."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PDFProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return PDFExporter()


class JSONProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return JSONExporter()


class XMLProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return XMLExporter()


class CSVProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return CSVExporter()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Calculate the final price."""
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VIPDiscount(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: subclasses implement the Factory Method
# ---------------------------------------------------------------------------

class DiscountEngine(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory Method: concrete engines choose the discount policy."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.calculate(price, items_count)


class RegularDiscountEngine(DiscountEngine):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VIPDiscountEngine(DiscountEngine):
    def create_policy(self) -> DiscountPolicy:
        return VIPDiscount()


class StudentDiscountEngine(DiscountEngine):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountEngine(DiscountEngine):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ---------------------------------------------------------------------------
# Existing public interface
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Store creator classes rather than shared product instances.
        self._document_processors: dict[str, type[DocumentProcessor]] = {
            "pdf": PDFProcessor,
            "json": JSONProcessor,
            "xml": XMLProcessor,
            "csv": CSVProcessor,
        }

        self._discount_engines: dict[str, type[DiscountEngine]] = {
            "REGULAR": RegularDiscountEngine,
            "VIP": VIPDiscountEngine,
            "STUDENT": StudentDiscountEngine,
        }

    def register_document_processor(
        self,
        format_type: str,
        processor_class: type[DocumentProcessor],
    ) -> None:
        """Register or replace a creator with a no-argument constructor."""
        self._document_processors[format_type.lower()] = processor_class

    def register_discount_engine(
        self,
        customer_type: str,
        engine_class: type[DiscountEngine],
    ) -> None:
        """Register or replace a creator with a no-argument constructor."""
        self._discount_engines[customer_type] = engine_class

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve baseline behavior: validate before selecting the format.
        if not data:
            return "Error: No data"

        processor_class = self._document_processors.get(format_type.lower())
        if processor_class is None:
            raise ValueError("Unsupported format")

        return processor_class().process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        engine_class = self._discount_engines.get(
            customer_type,
            NoDiscountEngine,
        )
        return engine_class().calculate(price, items_count)


# ---------------------------------------------------------------------------
# Execution simulation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    system = MonolithicSystem()

    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
