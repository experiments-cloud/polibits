# Extracted automatically from sample_08.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Produce the simulated document representation."""
        raise NotImplementedError


class PDFExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JSONExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f'{{"data": "{data}"}}'


class XMLExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CSVExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: subclasses implement the Factory Method
# ---------------------------------------------------------------------------

class DocumentProcessor(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory Method: select the exporter implementation."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PDFDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return PDFExporter()


class JSONDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return JSONExporter()


class XMLDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return XMLExporter()


class CSVDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return CSVExporter()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Return the final price without introducing additional rounding."""
        raise NotImplementedError


class RegularDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VIPDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: subclasses implement the Factory Method
# ---------------------------------------------------------------------------

class DiscountCalculator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory Method: select the discount implementation."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscountPolicy()


class VIPDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return VIPDiscountPolicy()


class StudentDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscountPolicy()


class NoDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscountPolicy()


# ---------------------------------------------------------------------------
# Existing public facade
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version = "1.0 - Baseline"

        # Instance-local registries avoid sharing mutable configuration
        # between independent system instances.
        self._document_creators: dict[str, type[DocumentProcessor]] = {
            "pdf": PDFDocumentProcessor,
            "json": JSONDocumentProcessor,
            "xml": XMLDocumentProcessor,
            "csv": CSVDocumentProcessor,
        }

        self._discount_creators: dict[str, type[DiscountCalculator]] = {
            "REGULAR": RegularDiscountCalculator,
            "VIP": VIPDiscountCalculator,
            "STUDENT": StudentDiscountCalculator,
        }

    def register_document_processor(
        self,
        format_type: str,
        creator: type[DocumentProcessor],
        *,
        replace: bool = False,
    ) -> None:
        """Register a creator whose constructor requires no arguments."""
        key = format_type.lower()

        if key in self._document_creators and not replace:
            raise ValueError(f"Document format already registered: {key}")

        self._document_creators[key] = creator

    def register_discount_calculator(
        self,
        customer_type: str,
        creator: type[DiscountCalculator],
        *,
        replace: bool = False,
    ) -> None:
        """Register a creator whose constructor requires no arguments."""
        if customer_type in self._discount_creators and not replace:
            raise ValueError(
                f"Customer type already registered: {customer_type}"
            )

        self._discount_creators[customer_type] = creator

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve the original validation order: empty data returns an
        # error even when the requested format is unsupported.
        if not data:
            return "Error: No data"

        creator_class = self._document_creators.get(format_type.lower())
        if creator_class is None:
            raise ValueError("Unsupported format")

        processor = creator_class()
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        # Customer identifiers remain case-sensitive. Unknown identifiers
        # retain the original behavior: no discount.
        creator_class = self._discount_creators.get(
            customer_type,
            NoDiscountCalculator,
        )

        calculator = creator_class()
        return calculator.calculate(price, items_count)


# ---------------------------------------------------------------------------
# Execution simulation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    system = MonolithicSystem()

    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
