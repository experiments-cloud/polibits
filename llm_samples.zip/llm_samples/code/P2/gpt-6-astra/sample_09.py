# Extracted automatically from sample_09.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Return the document representation."""


class PDFExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JSONExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f'{{"data": "{data}"}}'


class XMLExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CSVExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: each subclass overrides the factory method
# ---------------------------------------------------------------------------

class DocumentCreator(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory method implemented by concrete creators."""

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PDFCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return PDFExporter()


class JSONCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return JSONExporter()


class XMLCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return XMLExporter()


class CSVCreator(DocumentCreator):
    def create_exporter(self) -> DocumentExporter:
        return CSVExporter()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price."""


class RegularDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VIPDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: each subclass overrides the factory method
# ---------------------------------------------------------------------------

class DiscountCreator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory method implemented by concrete creators."""

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VIPDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return VIPDiscount()


class StudentDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ---------------------------------------------------------------------------
# Compatibility facade and creator selection
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Registries are instance-local to avoid shared mutable configuration.
        self._document_creators: dict[str, DocumentCreator] = {
            "pdf": PDFCreator(),
            "json": JSONCreator(),
            "xml": XMLCreator(),
            "csv": CSVCreator(),
        }

        self._discount_creators: dict[str, DiscountCreator] = {
            "REGULAR": RegularDiscountCreator(),
            "VIP": VIPDiscountCreator(),
            "STUDENT": StudentDiscountCreator(),
        }

        self._default_discount_creator: DiscountCreator = NoDiscountCreator()

    def register_document_creator(
        self,
        format_type: str,
        creator: DocumentCreator,
    ) -> None:
        """Register a format without silently replacing an existing creator."""
        key = format_type.lower()
        if key in self._document_creators:
            raise ValueError(f"Document format already registered: {key}")

        self._document_creators[key] = creator

    def register_discount_creator(
        self,
        customer_type: str,
        creator: DiscountCreator,
    ) -> None:
        """Register a case-sensitive customer category."""
        if customer_type in self._discount_creators:
            raise ValueError(
                f"Customer type already registered: {customer_type}"
            )

        self._discount_creators[customer_type] = creator

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve the baseline's validation order and truthiness semantics.
        # Even an unsupported format returns this error when data is empty.
        if not data:
            return "Error: No data"

        creator = self._document_creators.get(format_type.lower())
        if creator is None:
            raise ValueError("Unsupported format")

        return creator.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        creator = self._discount_creators.get(
            customer_type,
            self._default_discount_creator,
        )
        return creator.calculate(price, items_count)


# ---------------------------------------------------------------------------
# Execution simulation and compatibility smoke tests
# ---------------------------------------------------------------------------

def main() -> None:
    system = MonolithicSystem()

    expected_documents: dict[str, str] = {
        "pdf": "<PDF Document>Research Report</PDF Document>",
        "json": '{"data": "Research Report"}',
        "xml": "<xml><data>Research Report</data></xml>",
        "csv": "header,data\n1,Research Report",
    }

    for format_type, expected in expected_documents.items():
        assert (
            system.execute_document_process(
                format_type.upper(), "Research Report"
            )
            == expected
        )

    assert system.execute_document_process("unsupported", "") == "Error: No data"

    try:
        system.execute_document_process("unsupported", "Research Report")
    except ValueError as error:
        assert str(error) == "Unsupported format"
    else:
        raise AssertionError("Unsupported formats must raise ValueError")

    discount_cases: list[tuple[str, float, int, float]] = [
        ("REGULAR", 100.0, 10, 100.0),
        ("REGULAR", 100.0, 11, 95.0),
        ("VIP", 1000.0, 5, 900.0),
        ("VIP", 1200.0, 5, 1020.0),
        ("STUDENT", 100.0, 1, 80.0),
        ("UNKNOWN", 100.0, 20, 100.0),
        ("vip", 1200.0, 5, 1200.0),
    ]

    for customer_type, price, items_count, expected in discount_cases:
        assert (
            system.execute_ecommerce_discounts(
                customer_type, price, items_count
            )
            == expected
        )

    print(system.execute_document_process("pdf", "Research Report"))
    print(
        f"Final price: $"
        f"{system.execute_ecommerce_discounts('VIP', 1200.0, 5):.2f}"
    )


if __name__ == "__main__":
    main()
