# Extracted automatically from sample_07.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentProcessor(ABC):
    @abstractmethod
    def render(self, data: object) -> str:
        """Render data in the processor's document format."""
        raise NotImplementedError


class PdfProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        # Preserve the baseline's simulated output exactly.
        return f'{{"data": "{data}"}}'


class XmlProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvProcessor(DocumentProcessor):
    def render(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: subclasses override the factory method.
# ---------------------------------------------------------------------------

class DocumentCreator(ABC):
    @abstractmethod
    def create_processor(self) -> DocumentProcessor:
        """Factory method implemented by concrete creators."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        processor = self.create_processor()
        return processor.render(data)


class PdfCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return PdfProcessor()


class JsonCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return JsonProcessor()


class XmlCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return XmlProcessor()


class CsvCreator(DocumentCreator):
    def create_processor(self) -> DocumentProcessor:
        return CsvProcessor()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price."""
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VipDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: subclasses override the factory method.
# ---------------------------------------------------------------------------

class DiscountCreator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory method implemented by concrete creators."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VipDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return VipDiscount()


class StudentDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCreator(DiscountCreator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ---------------------------------------------------------------------------
# Existing facade
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version = "1.0 - Baseline"

        # Per-instance registries prevent changes from leaking across systems.
        # Registered creator classes must support construction without arguments.
        self._document_creators: dict[str, type[DocumentCreator]] = {
            "pdf": PdfCreator,
            "json": JsonCreator,
            "xml": XmlCreator,
            "csv": CsvCreator,
        }
        self._discount_creators: dict[str, type[DiscountCreator]] = {
            "REGULAR": RegularDiscountCreator,
            "VIP": VipDiscountCreator,
            "STUDENT": StudentDiscountCreator,
        }

    def register_document_creator(
        self,
        format_type: str,
        creator_type: type[DocumentCreator],
    ) -> None:
        """Add or replace a creator; document format keys are case-insensitive."""
        self._document_creators[format_type.lower()] = creator_type

    def register_discount_creator(
        self,
        customer_type: str,
        creator_type: type[DiscountCreator],
    ) -> None:
        """Add or replace a creator; customer keys remain case-sensitive."""
        self._discount_creators[customer_type] = creator_type

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve validation order: empty data wins over unsupported format.
        if not data:
            return "Error: No data"

        creator_type = self._document_creators.get(format_type.lower())
        if creator_type is None:
            raise ValueError("Unsupported format")

        return creator_type().process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        creator_type = self._discount_creators.get(
            customer_type,
            NoDiscountCreator,
        )
        return creator_type().calculate(price, items_count)


# ---------------------------------------------------------------------------
# Standard-library-only compatibility checks
# ---------------------------------------------------------------------------

def run_compatibility_checks() -> None:
    system = MonolithicSystem()

    expected_documents = {
        "pdf": "<PDF Document>Report</PDF Document>",
        "json": '{"data": "Report"}',
        "xml": "<xml><data>Report</data></xml>",
        "csv": "header,data\n1,Report",
    }
    for format_type, expected in expected_documents.items():
        assert system.execute_document_process(format_type, "Report") == expected

    assert system.execute_document_process("PDF", "Report") == (
        expected_documents["pdf"]
    )
    assert system.execute_document_process("unsupported", "") == "Error: No data"
    assert system.execute_document_process("pdf", None) == "Error: No data"

    try:
        system.execute_document_process("unsupported", "Report")
    except ValueError as exc:
        assert str(exc) == "Unsupported format"
    else:
        raise AssertionError("Unsupported formats must raise ValueError")

    assert system.execute_ecommerce_discounts("REGULAR", 100.0, 10) == 100.0
    assert system.execute_ecommerce_discounts("REGULAR", 100.0, 11) == 95.0
    assert system.execute_ecommerce_discounts("VIP", 1000.0, 5) == 900.0
    assert system.execute_ecommerce_discounts("VIP", 1200.0, 5) == 1020.0
    assert system.execute_ecommerce_discounts("STUDENT", 100.0, 1) == 80.0
    assert system.execute_ecommerce_discounts("UNKNOWN", 100.0, 20) == 100.0
    assert system.execute_ecommerce_discounts("vip", 100.0, 5) == 100.0


if __name__ == "__main__":
    run_compatibility_checks()

    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200.0, 5))
