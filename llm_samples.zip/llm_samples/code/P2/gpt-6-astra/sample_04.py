# Extracted automatically from sample_04.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod


# ============================================================
# Document products
# ============================================================

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Produce the document representation."""
        raise NotImplementedError


class PdfExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f'{{"data": "{data}"}}'


class XmlExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ============================================================
# Document creators: Factory Method
# ============================================================

class DocumentProcessor(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory method implemented by concrete creators."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PdfProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return PdfExporter()


class JsonProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return JsonExporter()


class XmlProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return XmlExporter()


class CsvProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return CsvExporter()


# ============================================================
# Discount products
# ============================================================

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price."""
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VipDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ============================================================
# Discount creators: Factory Method
# ============================================================

class DiscountCalculator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory method implemented by concrete creators."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VipDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return VipDiscount()


class StudentDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ============================================================
# Compatibility facade and creator registries
# ============================================================

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Registries belong to each system instance, avoiding
        # mutable global configuration shared across instances.
        self._document_processors: dict[str, DocumentProcessor] = {
            "pdf": PdfProcessor(),
            "json": JsonProcessor(),
            "xml": XmlProcessor(),
            "csv": CsvProcessor(),
        }

        self._discount_calculators: dict[str, DiscountCalculator] = {
            "REGULAR": RegularDiscountCalculator(),
            "VIP": VipDiscountCalculator(),
            "STUDENT": StudentDiscountCalculator(),
        }

        self._default_discount_calculator: DiscountCalculator = (
            NoDiscountCalculator()
        )

    def register_document_processor(
        self,
        format_type: str,
        processor: DocumentProcessor,
    ) -> None:
        """Register or replace a creator for a document format."""
        self._document_processors[format_type.lower()] = processor

    def register_discount_calculator(
        self,
        customer_type: str,
        calculator: DiscountCalculator,
    ) -> None:
        """Register or replace a creator for an exact customer category."""
        self._discount_calculators[customer_type] = calculator

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve the original validation order and truthiness check.
        if not data:
            return "Error: No data"

        processor = self._document_processors.get(format_type.lower())
        if processor is None:
            raise ValueError("Unsupported format")

        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        calculator = self._discount_calculators.get(
            customer_type,
            self._default_discount_calculator,
        )
        return calculator.calculate(price, items_count)


# ============================================================
# Execution simulation
# ============================================================

def main() -> None:
    system = MonolithicSystem()

    document = system.execute_document_process(
        "pdf",
        "Research Report",
    )
    final_price = system.execute_ecommerce_discounts(
        "VIP",
        1200,
        5,
    )

    print(document)
    print(f"Final price: ${final_price:.2f}")


if __name__ == "__main__":
    main()
