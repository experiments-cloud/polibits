# Extracted automatically from sample_10.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Render data using the exporter's format."""
        raise NotImplementedError


class PdfExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonExporter(DocumentExporter):
    def export(self, data: object) -> str:
        # Preserve the baseline's exact formatting behavior.
        return f'{{"data": "{data}"}}'


class XmlExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvExporter(DocumentExporter):
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: subclasses implement the Factory Method.
# ---------------------------------------------------------------------------

class DocumentProcessor(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory Method: create the product used by this processor."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PdfDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return PdfExporter()


class JsonDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return JsonExporter()


class XmlDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return XmlExporter()


class CsvDocumentProcessor(DocumentProcessor):
    def create_exporter(self) -> DocumentExporter:
        return CsvExporter()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price."""
        raise NotImplementedError


class RegularDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VipDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscountPolicy(DiscountPolicy):
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: subclasses implement the Factory Method.
# ---------------------------------------------------------------------------

class DiscountCalculator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory Method: create the policy used by this calculator."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscountPolicy()


class VipDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return VipDiscountPolicy()


class StudentDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscountPolicy()


class NoDiscountCalculator(DiscountCalculator):
    def create_policy(self) -> DiscountPolicy:
        return NoDiscountPolicy()


# ---------------------------------------------------------------------------
# Existing public interface
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Instance-local registries avoid shared mutable configuration.
        # Registered creator classes must support construction without arguments.
        self._document_processors: dict[str, type[DocumentProcessor]] = {
            "pdf": PdfDocumentProcessor,
            "json": JsonDocumentProcessor,
            "xml": XmlDocumentProcessor,
            "csv": CsvDocumentProcessor,
        }

        self._discount_calculators: dict[str, type[DiscountCalculator]] = {
            "REGULAR": RegularDiscountCalculator,
            "VIP": VipDiscountCalculator,
            "STUDENT": StudentDiscountCalculator,
        }

    def register_document_processor(
        self,
        format_type: str,
        processor_class: type[DocumentProcessor],
    ) -> None:
        """Register a format without replacing an existing registration."""
        key = format_type.lower()

        if key in self._document_processors:
            raise ValueError(f"Document format already registered: {key}")

        self._document_processors[key] = processor_class

    def register_discount_calculator(
        self,
        customer_type: str,
        calculator_class: type[DiscountCalculator],
    ) -> None:
        """Register a case-sensitive customer category."""
        if customer_type in self._discount_calculators:
            raise ValueError(
                f"Customer type already registered: {customer_type}"
            )

        self._discount_calculators[customer_type] = calculator_class

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve the baseline's validation order and falsy-input behavior.
        if not data:
            return "Error: No data"

        processor_class = self._document_processors.get(format_type.lower())

        if processor_class is None:
            raise ValueError("Unsupported format")

        return processor_class().process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        # Unknown customer categories retain the baseline's no-discount behavior.
        calculator_class = self._discount_calculators.get(
            customer_type,
            NoDiscountCalculator,
        )

        return calculator_class().calculate(price, items_count)


# ---------------------------------------------------------------------------
# Lightweight regression checks; no external dependencies.
# ---------------------------------------------------------------------------

def run_regression_checks() -> None:
    system = MonolithicSystem()

    expected_documents: dict[str, str] = {
        "pdf": "<PDF Document>Report</PDF Document>",
        "json": '{"data": "Report"}',
        "xml": "<xml><data>Report</data></xml>",
        "csv": "header,data\n1,Report",
    }

    for format_type, expected in expected_documents.items():
        assert system.execute_document_process(format_type, "Report") == expected

    assert system.execute_document_process("PDF", "Report") == (
        expected_documents["pdf"]
    )

    for empty_data in (None, "", 0, False, [], {}):
        assert system.execute_document_process(
            "unsupported", empty_data
        ) == "Error: No data"

    try:
        system.execute_document_process("unsupported", "Report")
    except ValueError as error:
        assert str(error) == "Unsupported format"
    else:
        raise AssertionError("Unsupported formats must raise ValueError")

    discount_cases: list[tuple[str, float, int, float]] = [
        ("REGULAR", 100.0, 10, 100.0),
        ("REGULAR", 100.0, 11, 95.0),
        ("VIP", 1000.0, 5, 900.0),
        ("VIP", 1200.0, 5, 1020.0),
        ("STUDENT", 100.0, 1, 80.0),
        ("UNKNOWN", 100.0, 20, 100.0),
        ("vip", 100.0, 20, 100.0),
    ]

    for customer_type, price, items_count, expected in discount_cases:
        assert system.execute_ecommerce_discounts(
            customer_type, price, items_count
        ) == expected


if __name__ == "__main__":
    run_regression_checks()

    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200.0, 5))
