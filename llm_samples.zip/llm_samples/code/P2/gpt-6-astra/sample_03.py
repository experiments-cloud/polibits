# Extracted automatically from sample_03.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod
from typing import override


# ---------------------------------------------------------------------------
# Document products
# ---------------------------------------------------------------------------

class DocumentExporter(ABC):
    @abstractmethod
    def export(self, data: object) -> str:
        """Render data using the existing simulated document format."""
        raise NotImplementedError


class PdfExporter(DocumentExporter):
    @override
    def export(self, data: object) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonExporter(DocumentExporter):
    @override
    def export(self, data: object) -> str:
        return f'{{"data": "{data}"}}'


class XmlExporter(DocumentExporter):
    @override
    def export(self, data: object) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvExporter(DocumentExporter):
    @override
    def export(self, data: object) -> str:
        return f"header,data\n1,{data}"


# ---------------------------------------------------------------------------
# Document creators: subclasses implement the Factory Method
# ---------------------------------------------------------------------------

class DocumentProcessor(ABC):
    @abstractmethod
    def create_exporter(self) -> DocumentExporter:
        """Factory Method implemented by concrete creators."""
        raise NotImplementedError

    def process(self, data: object) -> str:
        exporter = self.create_exporter()
        return exporter.export(data)


class PdfProcessor(DocumentProcessor):
    @override
    def create_exporter(self) -> DocumentExporter:
        return PdfExporter()


class JsonProcessor(DocumentProcessor):
    @override
    def create_exporter(self) -> DocumentExporter:
        return JsonExporter()


class XmlProcessor(DocumentProcessor):
    @override
    def create_exporter(self) -> DocumentExporter:
        return XmlExporter()


class CsvProcessor(DocumentProcessor):
    @override
    def create_exporter(self) -> DocumentExporter:
        return CsvExporter()


# ---------------------------------------------------------------------------
# Discount products
# ---------------------------------------------------------------------------

class DiscountPolicy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price using the existing business rules."""
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    @override
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price


class VipDiscount(DiscountPolicy):
    @override
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90


class StudentDiscount(DiscountPolicy):
    @override
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountPolicy):
    @override
    def apply(self, price: float, items_count: int) -> float:
        return price


# ---------------------------------------------------------------------------
# Discount creators: subclasses implement the Factory Method
# ---------------------------------------------------------------------------

class DiscountCalculator(ABC):
    @abstractmethod
    def create_policy(self) -> DiscountPolicy:
        """Factory Method implemented by concrete creators."""
        raise NotImplementedError

    def calculate(self, price: float, items_count: int) -> float:
        policy = self.create_policy()
        return policy.apply(price, items_count)


class RegularDiscountCalculator(DiscountCalculator):
    @override
    def create_policy(self) -> DiscountPolicy:
        return RegularDiscount()


class VipDiscountCalculator(DiscountCalculator):
    @override
    def create_policy(self) -> DiscountPolicy:
        return VipDiscount()


class StudentDiscountCalculator(DiscountCalculator):
    @override
    def create_policy(self) -> DiscountPolicy:
        return StudentDiscount()


class NoDiscountCalculator(DiscountCalculator):
    @override
    def create_policy(self) -> DiscountPolicy:
        return NoDiscount()


# ---------------------------------------------------------------------------
# Compatibility façade and creator registries
# ---------------------------------------------------------------------------

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "1.0 - Baseline"

        # Registries are instance-local, avoiding shared mutable global state.
        # Creators are stateless; their factory methods create fresh products.
        self._document_processors: dict[str, DocumentProcessor] = {
            "pdf": PdfProcessor(),
            "json": JsonProcessor(),
            "xml": XmlProcessor(),
            "csv": CsvProcessor(),
        }

        self._discount_calculators: dict[str, DiscountCalculator] = {
            "REGULAR": RegularDiscountCalculator(),
            "VIP": VipDiscountCalculator(),
            "STUDENT": StudentDiscountCalculator(),
        }

        self._default_discount_calculator: DiscountCalculator = (
            NoDiscountCalculator()
        )

    def register_document_processor(
        self,
        format_type: str,
        processor: DocumentProcessor,
    ) -> None:
        """Register a new format without silently replacing an existing one."""
        key = format_type.lower()
        if key in self._document_processors:
            raise ValueError(f"Document format already registered: {format_type}")
        self._document_processors[key] = processor

    def register_discount_calculator(
        self,
        customer_type: str,
        calculator: DiscountCalculator,
    ) -> None:
        """Register a new case-sensitive customer category."""
        if customer_type in self._discount_calculators:
            raise ValueError(
                f"Customer type already registered: {customer_type}"
            )
        self._discount_calculators[customer_type] = calculator

    def execute_document_process(
        self,
        format_type: str,
        data: object,
    ) -> str:
        # Preserve the original validation order: falsy data returns this
        # error even when the requested format is unsupported.
        if not data:
            return "Error: No data"

        processor = self._document_processors.get(format_type.lower())
        if processor is None:
            raise ValueError("Unsupported format")

        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        # Preserve case-sensitive selection and the no-discount fallback.
        calculator = self._discount_calculators.get(
            customer_type,
            self._default_discount_calculator,
        )
        return calculator.calculate(price, items_count)


# ---------------------------------------------------------------------------
# Execution simulation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    system = MonolithicSystem()

    document = system.execute_document_process("pdf", "Research Report")
    final_price = system.execute_ecommerce_discounts("VIP", 1200, 5)

    print(document)
    print(f"Final price: ${final_price:.2f}")
