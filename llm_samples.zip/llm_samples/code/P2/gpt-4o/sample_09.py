# Extracted automatically from sample_09.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod
from typing import Protocol

# Document Processing
class DocumentProcessor(Protocol):
    def process(self, data: str) -> str:
        ...

class PDFProcessor:
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"

class JSONProcessor:
    def process(self, data: str) -> str:
        return f"{{\"data\": \"{data}\"}}"

class XMLProcessor:
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"

class CSVProcessor:
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"

class DocumentProcessorFactory:
    @staticmethod
    def get_processor(format_type: str) -> DocumentProcessor:
        processors = {
            "pdf": PDFProcessor(),
            "json": JSONProcessor(),
            "xml": XMLProcessor(),
            "csv": CSVProcessor()
        }
        processor = processors.get(format_type.lower())
        if not processor:
            raise ValueError("Unsupported format")
        return processor

# Discount Calculation
class DiscountCalculator(Protocol):
    def calculate(self, price: float, items_count: int) -> float:
        ...

class RegularDiscountCalculator:
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price

class VIPDiscountCalculator:
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90

class StudentDiscountCalculator:
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80

class DiscountCalculatorFactory:
    @staticmethod
    def get_calculator(customer_type: str) -> DiscountCalculator:
        calculators = {
            "regular": RegularDiscountCalculator(),
            "vip": VIPDiscountCalculator(),
            "student": StudentDiscountCalculator()
        }
        calculator = calculators.get(customer_type.lower())
        if not calculator:
            raise ValueError("Unsupported customer type")
        return calculator

# Monolithic System Refactored
class MonolithicSystem:
    def __init__(self):
        self.version = "1.0 - Refactored"

    def execute_document_process(self, format_type: str, data: str) -> str:
        if not data:
            return "Error: No data"
        processor = DocumentProcessorFactory.get_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        calculator = DiscountCalculatorFactory.get_calculator(customer_type)
        return calculator.calculate(price, items_count)

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
