# Extracted automatically from sample_06.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod
from typing import Dict, Type

# Document Processing
class DocumentProcessor(ABC):
    @abstractmethod
    def process(self, data: str) -> str:
        pass

class PDFProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"

class JSONProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"{{\"data\": \"{data}\"}}"

class XMLProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"

class CSVProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"

class DocumentProcessorFactory:
    _processors: Dict[str, Type[DocumentProcessor]] = {
        "pdf": PDFProcessor,
        "json": JSONProcessor,
        "xml": XMLProcessor,
        "csv": CSVProcessor
    }

    @staticmethod
    def get_processor(format_type: str) -> DocumentProcessor:
        processor_class = DocumentProcessorFactory._processors.get(format_type.lower())
        if not processor_class:
            raise ValueError("Unsupported format")
        return processor_class()

# Discount Calculation
class DiscountCalculator(ABC):
    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        pass

class RegularDiscountCalculator(DiscountCalculator):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price

class VIPDiscountCalculator(DiscountCalculator):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90

class StudentDiscountCalculator(DiscountCalculator):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80

class DiscountCalculatorFactory:
    _calculators: Dict[str, Type[DiscountCalculator]] = {
        "regular": RegularDiscountCalculator,
        "vip": VIPDiscountCalculator,
        "student": StudentDiscountCalculator
    }

    @staticmethod
    def get_calculator(customer_type: str) -> DiscountCalculator:
        calculator_class = DiscountCalculatorFactory._calculators.get(customer_type.lower())
        if not calculator_class:
            raise ValueError("Unsupported customer type")
        return calculator_class()

# Monolithic System Refactored
class MonolithicSystem:
    def __init__(self):
        self.version = "2.0 - Refactored"

    def execute_document_process(self, format_type: str, data: str) -> str:
        if not data:
            return "Error: No data"
        processor = DocumentProcessorFactory.get_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        calculator = DiscountCalculatorFactory.get_calculator(customer_type)
        return calculator.calculate(price, items_count)

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
