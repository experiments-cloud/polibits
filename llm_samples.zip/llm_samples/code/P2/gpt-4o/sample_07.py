# Extracted automatically from sample_07.md by generate_samples.py (fenced:1)
# p1_refactored.py
from abc import ABC, abstractmethod
from typing import Type

# Document Processing Logic

class DocumentProcessor(ABC):
    @abstractmethod
    def process(self, data: str) -> str:
        pass

class PDFProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"

class JSONProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"{{\"data\": \"{data}\"}}"

class XMLProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"

class CSVProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"

class DocumentProcessorFactory:
    @staticmethod
    def get_processor(format_type: str) -> DocumentProcessor:
        processors = {
            "pdf": PDFProcessor,
            "json": JSONProcessor,
            "xml": XMLProcessor,
            "csv": CSVProcessor
        }
        processor_class = processors.get(format_type.lower())
        if not processor_class:
            raise ValueError("Unsupported format")
        return processor_class()

# Discount Calculation Logic

class DiscountStrategy(ABC):
    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        pass

class RegularDiscount(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.95 if items_count > 10 else price

class VIPDiscount(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.85 if price > 1000 else price * 0.90

class StudentDiscount(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80

class NoDiscount(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price

class DiscountStrategyFactory:
    @staticmethod
    def get_strategy(customer_type: str) -> DiscountStrategy:
        strategies = {
            "regular": RegularDiscount,
            "vip": VIPDiscount,
            "student": StudentDiscount
        }
        strategy_class = strategies.get(customer_type.lower(), NoDiscount)
        return strategy_class()

# Monolithic System Refactored

class MonolithicSystem:
    def __init__(self):
        self.version = "1.0 - Refactored"

    def execute_document_process(self, format_type: str, data: str) -> str:
        if not data:
            return "Error: No data"
        processor = DocumentProcessorFactory.get_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        strategy = DiscountStrategyFactory.get_strategy(customer_type)
        return strategy.calculate(price, items_count)

# Execution simulation
if __name__ == "__main__":
    system = MonolithicSystem()
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_ecommerce_discounts("VIP", 1200, 5))
