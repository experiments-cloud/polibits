# Extracted automatically from sample_10.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Type


# =========================
# Document Processing Logic
# =========================

class DocumentProcessor(ABC):
    """Abstract product for document export behavior."""

    @abstractmethod
    def process(self, data: str) -> str:
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    """
    Factory Method creator for document processors.

    Uses a registry-based structure for scalability:
    adding support for a new format only requires a new processor class
    and a registration entry.
    """

    _registry: Dict[str, Type[DocumentProcessor]] = {
        "pdf": PdfDocumentProcessor,
        "json": JsonDocumentProcessor,
        "xml": XmlDocumentProcessor,
        "csv": CsvDocumentProcessor,
    }

    @classmethod
    def create_processor(cls, format_type: str) -> DocumentProcessor:
        key = format_type.strip().lower()
        processor_class = cls._registry.get(key)
        if processor_class is None:
            raise ValueError(f"Unsupported format: {format_type}")
        return processor_class()

    @classmethod
    def register(cls, format_type: str, processor_class: Type[DocumentProcessor]) -> None:
        cls._registry[format_type.strip().lower()] = processor_class


# ====================
# Discount Engine Logic
# ====================

class DiscountStrategy(ABC):
    """Abstract product for discount calculation behavior."""

    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory:
    """
    Factory Method creator for discount strategies.

    Registry-based selection allows scalable growth of customer types
    without modifying the consumer code.
    """

    _registry: Dict[str, Type[DiscountStrategy]] = {
        "REGULAR": RegularDiscountStrategy,
        "VIP": VipDiscountStrategy,
        "STUDENT": StudentDiscountStrategy,
    }

    @classmethod
    def create_strategy(cls, customer_type: str) -> DiscountStrategy:
        key = customer_type.strip().upper()
        strategy_class = cls._registry.get(key, DefaultDiscountStrategy)
        return strategy_class()

    @classmethod
    def register(cls, customer_type: str, strategy_class: Type[DiscountStrategy]) -> None:
        cls._registry[customer_type.strip().upper()] = strategy_class


# ==========================
# Refactored System Facade
# ==========================

class MonolithicSystem:
    """
    Preserves the public intent of the original system while delegating
    document processing and discount calculation to Factory Method-based components.
    """

    def __init__(self) -> None:
        self.version: str = "2.0 - Refactored with Factory Method"

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Refactored document processing."""
        if not data:
            return "Error: No data"

        processor = DocumentProcessorFactory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """Refactored discount calculation."""
        strategy = DiscountStrategyFactory.create_strategy(customer_type)
        return strategy.apply(price, items_count)


# =================
# Execution Example
# =================

if __name__ == "__main__":
    system = MonolithicSystem()

    # Document processing examples
    print(system.execute_document_process("pdf", "Research Report"))
    print(system.execute_document_process("json", "Research Report"))
    print(system.execute_document_process("xml", "Research Report"))
    print(system.execute_document_process("csv", "Research Report"))

    # Discount calculation examples
    print(f"{system.execute_ecommerce_discounts('REGULAR', 500, 12):.2f}")
    print(f"{system.execute_ecommerce_discounts('VIP', 1200, 5):.2f}")
    print(f"{system.execute_ecommerce_discounts('STUDENT', 300, 2):.2f}")
    print(f"{system.execute_ecommerce_discounts('UNKNOWN', 300, 2):.2f}")
