# Extracted automatically from sample_07.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, Dict


# =========================
# Document Processing
# =========================

class DocumentProcessor(ABC):
    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into a concrete document representation."""
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    _creators: Dict[str, Callable[[], DocumentProcessor]] = {
        "pdf": PdfDocumentProcessor,
        "json": JsonDocumentProcessor,
        "xml": XmlDocumentProcessor,
        "csv": CsvDocumentProcessor,
    }

    @classmethod
    def create_processor(cls, format_type: str) -> DocumentProcessor:
        key = format_type.strip().lower()
        creator = cls._creators.get(key)
        if creator is None:
            raise ValueError(f"Unsupported format: {format_type}")
        return creator()

    @classmethod
    def register_processor(
        cls,
        format_type: str,
        creator: Callable[[], DocumentProcessor],
    ) -> None:
        cls._creators[format_type.strip().lower()] = creator


# =========================
# Discount Logic
# =========================

class DiscountStrategy(ABC):
    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Calculate final price after discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscountStrategy(DiscountStrategy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory:
    _creators: Dict[str, Callable[[], DiscountStrategy]] = {
        "REGULAR": RegularDiscountStrategy,
        "VIP": VipDiscountStrategy,
        "STUDENT": StudentDiscountStrategy,
    }

    @classmethod
    def create_strategy(cls, customer_type: str) -> DiscountStrategy:
        key = customer_type.strip().upper()
        creator = cls._creators.get(key, DefaultDiscountStrategy)
        return creator()

    @classmethod
    def register_strategy(
        cls,
        customer_type: str,
        creator: Callable[[], DiscountStrategy],
    ) -> None:
        cls._creators[customer_type.strip().upper()] = creator


# =========================
# Refactored System
# =========================

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "2.0 - Factory Method Refactor"

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Case 1: Document Processing through Factory Method."""
        if not data:
            return "Error: No data"

        processor = DocumentProcessorFactory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """Case 2: Discount calculation through Factory Method."""
        strategy = DiscountStrategyFactory.create_strategy(customer_type)
        return strategy.calculate(price, items_count)


# =========================
# Execution simulation
# =========================

if __name__ == "__main__":
    system = MonolithicSystem()

    document_result = system.execute_document_process("pdf", "Research Report")
    print(document_result)

    discounted_price = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"Final price: ${discounted_price:.2f}")
