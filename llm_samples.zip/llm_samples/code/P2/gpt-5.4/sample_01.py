# Extracted automatically from sample_01.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Type


# =========================
# Document Processing Logic
# =========================

class DocumentProcessor(ABC):
    """Abstract product for document processing."""

    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into the target document format."""
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    """Factory Method creator for document processors."""

    _registry: Dict[str, Type[DocumentProcessor]] = {
        "pdf": PdfDocumentProcessor,
        "json": JsonDocumentProcessor,
        "xml": XmlDocumentProcessor,
        "csv": CsvDocumentProcessor,
    }

    @classmethod
    def create_processor(cls, format_type: str) -> DocumentProcessor:
        key = format_type.strip().lower()
        processor_class = cls._registry.get(key)

        if processor_class is None:
            raise ValueError(f"Unsupported format: {format_type}")

        return processor_class()

    @classmethod
    def register_processor(
        cls,
        format_type: str,
        processor_class: Type[DocumentProcessor],
    ) -> None:
        cls._registry[format_type.strip().lower()] = processor_class


# ====================
# Discount Engine Logic
# ====================

class DiscountStrategy(ABC):
    """Abstract product for discount calculation."""

    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Calculate the final price after discount."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95  # 5% volume discount
        return price


class VipDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85  # 15% premium VIP discount
        return price * 0.90      # 10% standard VIP discount


class StudentDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80      # 20% fixed discount


class NoDiscountStrategy(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory:
    """Factory Method creator for discount strategies."""

    _registry: Dict[str, Type[DiscountStrategy]] = {
        "REGULAR": RegularDiscountStrategy,
        "VIP": VipDiscountStrategy,
        "STUDENT": StudentDiscountStrategy,
    }

    @classmethod
    def create_strategy(cls, customer_type: str) -> DiscountStrategy:
        key = customer_type.strip().upper()
        strategy_class = cls._registry.get(key, NoDiscountStrategy)
        return strategy_class()

    @classmethod
    def register_strategy(
        cls,
        customer_type: str,
        strategy_class: Type[DiscountStrategy],
    ) -> None:
        cls._registry[customer_type.strip().upper()] = strategy_class


# ==========================
# Refactored System Facade
# ==========================

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "2.0 - Factory Method Refactor"

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Case 1: Document Processing via Factory Method."""
        if not data:
            return "Error: No data"

        processor = DocumentProcessorFactory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """Case 2: Discount Engine via Factory Method."""
        strategy = DiscountStrategyFactory.create_strategy(customer_type)
        return strategy.apply(price, items_count)


# =================
# Execution Example
# =================

if __name__ == "__main__":
    system = MonolithicSystem()

    document_result = system.execute_document_process("pdf", "Research Report")
    print(document_result)

    discounted_price = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"Final price: ${discounted_price:.2f}")
