# Extracted automatically from sample_03.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, Dict


# =========================
# Document Processing Logic
# =========================

class DocumentProcessor(ABC):
    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into the target document format."""
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    def __init__(self) -> None:
        self._creators: Dict[str, Callable[[], DocumentProcessor]] = {
            "pdf": PdfDocumentProcessor,
            "json": JsonDocumentProcessor,
            "xml": XmlDocumentProcessor,
            "csv": CsvDocumentProcessor,
        }

    def create_processor(self, format_type: str) -> DocumentProcessor:
        normalized_type = format_type.strip().lower()
        creator = self._creators.get(normalized_type)

        if creator is None:
            raise ValueError(f"Unsupported format: {format_type}")

        return creator()

    def register(self, format_type: str, creator: Callable[[], DocumentProcessor]) -> None:
        self._creators[format_type.strip().lower()] = creator


# ======================
# Discount Processing Logic
# ======================

class DiscountStrategy(ABC):
    @abstractmethod
    def apply_discount(self, price: float, items_count: int) -> float:
        """Apply the discount policy and return the final price."""
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory:
    def __init__(self) -> None:
        self._creators: Dict[str, Callable[[], DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
        }

    def create_strategy(self, customer_type: str) -> DiscountStrategy:
        normalized_type = customer_type.strip().upper()
        creator = self._creators.get(normalized_type, DefaultDiscountStrategy)
        return creator()

    def register(self, customer_type: str, creator: Callable[[], DiscountStrategy]) -> None:
        self._creators[customer_type.strip().upper()] = creator


# ======================
# Refactored System
# ======================

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "2.0 - Factory Method Refactor"
        self._document_factory = DocumentProcessorFactory()
        self._discount_factory = DiscountStrategyFactory()

    def execute_document_process(self, format_type: str, data: str) -> str:
        if not data:
            return "Error: No data"

        processor = self._document_factory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        strategy = self._discount_factory.create_strategy(customer_type)
        return strategy.apply_discount(price, items_count)


# ======================
# Execution simulation
# ======================

if __name__ == "__main__":
    system = MonolithicSystem()

    doc_result = system.execute_document_process("pdf", "Research Report")
    print(doc_result)

    discount_result = system.execute_ecommerce_discounts("VIP", 1200, 5)
    print(f"Final price: ${discount_result:.2f}")
