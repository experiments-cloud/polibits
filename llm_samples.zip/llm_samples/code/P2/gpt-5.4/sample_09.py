# Extracted automatically from sample_09.md by generate_samples.py (fenced:1)
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Type


# =========================
# Document Processing Logic
# =========================

class DocumentProcessor(ABC):
    """Abstract product for document processing."""

    @abstractmethod
    def process(self, data: str) -> str:
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    """Factory Method creator for document processors."""

    _registry: Dict[str, Type[DocumentProcessor]] = {
        "pdf": PdfDocumentProcessor,
        "json": JsonDocumentProcessor,
        "xml": XmlDocumentProcessor,
        "csv": CsvDocumentProcessor,
    }

    @classmethod
    def create_processor(cls, format_type: str) -> DocumentProcessor:
        processor_cls = cls._registry.get(format_type.lower())
        if processor_cls is None:
            raise ValueError(f"Unsupported format: {format_type}")
        return processor_cls()

    @classmethod
    def register_processor(
        cls,
        format_type: str,
        processor_cls: Type[DocumentProcessor],
    ) -> None:
        cls._registry[format_type.lower()] = processor_cls


# =====================
# Discount Engine Logic
# =====================

class DiscountPolicy(ABC):
    """Abstract product for discount calculation."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        raise NotImplementedError


class RegularDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class DiscountPolicyFactory:
    """Factory Method creator for discount policies."""

    _registry: Dict[str, Type[DiscountPolicy]] = {
        "REGULAR": RegularDiscountPolicy,
        "VIP": VipDiscountPolicy,
        "STUDENT": StudentDiscountPolicy,
    }

    @classmethod
    def create_policy(cls, customer_type: str) -> DiscountPolicy:
        policy_cls = cls._registry.get(customer_type.upper(), DefaultDiscountPolicy)
        return policy_cls()

    @classmethod
    def register_policy(
        cls,
        customer_type: str,
        policy_cls: Type[DiscountPolicy],
    ) -> None:
        cls._registry[customer_type.upper()] = policy_cls


# =================
# Monolithic Facade
# =================

class MonolithicSystem:
    def __init__(self) -> None:
        self.version: str = "2.0 - Factory Method Refactor"

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Refactored document processing using Factory Method."""
        if not data:
            return "Error: No data"

        processor = DocumentProcessorFactory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """Refactored discount engine using Factory Method."""
        policy = DiscountPolicyFactory.create_policy(customer_type)
        return policy.calculate(price, items_count)


# ==================
# Execution Simulation
# ==================

if __name__ == "__main__":
    system = MonolithicSystem()

    doc_result = system.execute_document_process("pdf", "Research Report")
    print(doc_result)

    discount_result = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"{discount_result:.2f}")
