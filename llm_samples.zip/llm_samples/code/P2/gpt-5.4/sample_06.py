# Extracted automatically from sample_06.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, Dict


# =========================
# Document Processing
# =========================

class DocumentProcessor(ABC):
    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into a target document format."""


class PdfProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        escaped = data.replace('"', '\\"')
        return f'{{"data": "{escaped}"}}'


class XmlProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory(ABC):
    @abstractmethod
    def create_processor(self, format_type: str) -> DocumentProcessor:
        """Factory Method: create a processor for the given document format."""


class RegistryDocumentProcessorFactory(DocumentProcessorFactory):
    def __init__(self) -> None:
        self._registry: Dict[str, Callable[[], DocumentProcessor]] = {
            "pdf": PdfProcessor,
            "json": JsonProcessor,
            "xml": XmlProcessor,
            "csv": CsvProcessor,
        }

    def create_processor(self, format_type: str) -> DocumentProcessor:
        key = format_type.strip().lower()
        creator = self._registry.get(key)
        if creator is None:
            raise ValueError(f"Unsupported format: {format_type}")
        return creator()

    def register(self, format_type: str, creator: Callable[[], DocumentProcessor]) -> None:
        self._registry[format_type.strip().lower()] = creator


# =========================
# Discount Logic
# =========================

class DiscountStrategy(ABC):
    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Apply discount rules and return the final price."""


class RegularDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory(ABC):
    @abstractmethod
    def create_discount_strategy(self, customer_type: str) -> DiscountStrategy:
        """Factory Method: create a discount strategy for the customer type."""


class RegistryDiscountStrategyFactory(DiscountStrategyFactory):
    def __init__(self) -> None:
        self._registry: Dict[str, Callable[[], DiscountStrategy]] = {
            "REGULAR": RegularDiscount,
            "VIP": VipDiscount,
            "STUDENT": StudentDiscount,
        }

    def create_discount_strategy(self, customer_type: str) -> DiscountStrategy:
        key = customer_type.strip().upper()
        creator = self._registry.get(key, DefaultDiscount)
        return creator()

    def register(self, customer_type: str, creator: Callable[[], DiscountStrategy]) -> None:
        self._registry[customer_type.strip().upper()] = creator


# =========================
# Refactored System
# =========================

class RefactoredSystem:
    def __init__(
        self,
        document_factory: DocumentProcessorFactory | None = None,
        discount_factory: DiscountStrategyFactory | None = None,
    ) -> None:
        self.version: str = "2.0 - Factory Method Refactor"
        self._document_factory: DocumentProcessorFactory = (
            document_factory if document_factory is not None else RegistryDocumentProcessorFactory()
        )
        self._discount_factory: DiscountStrategyFactory = (
            discount_factory if discount_factory is not None else RegistryDiscountStrategyFactory()
        )

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Refactored document processing using Factory Method."""
        if not data:
            return "Error: No data"

        processor = self._document_factory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """Refactored discount calculation using Factory Method."""
        strategy = self._discount_factory.create_discount_strategy(customer_type)
        return strategy.apply(price, items_count)


# =========================
# Execution simulation
# =========================

if __name__ == "__main__":
    system = RefactoredSystem()

    doc_result = system.execute_document_process("pdf", "Research Report")
    print(doc_result)

    discount_result = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"Final price: ${discount_result:.2f}")
