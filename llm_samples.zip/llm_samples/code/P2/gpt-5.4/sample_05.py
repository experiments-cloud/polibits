# Extracted automatically from sample_05.md by generate_samples.py (fenced:1)
# p1_refactored_factory_method.py

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Type


# =========================
# Document Processing Logic
# =========================

class DocumentProcessor(ABC):
    """Product interface for document processors."""

    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into a target document representation."""
        raise NotImplementedError


class PdfProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"{{\"data\": \"{data}\"}}"


class XmlProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory(ABC):
    """Factory Method creator for document processors."""

    @abstractmethod
    def create_processor(self, format_type: str) -> DocumentProcessor:
        raise NotImplementedError


class RegistryDocumentProcessorFactory(DocumentProcessorFactory):
    """Scalable registry-based factory for document processors."""

    def __init__(self) -> None:
        self._registry: dict[str, Type[DocumentProcessor]] = {
            "pdf": PdfProcessor,
            "json": JsonProcessor,
            "xml": XmlProcessor,
            "csv": CsvProcessor,
        }

    def create_processor(self, format_type: str) -> DocumentProcessor:
        normalized: str = format_type.strip().lower()
        processor_cls = self._registry.get(normalized)
        if processor_cls is None:
            raise ValueError(f"Unsupported format: {format_type}")
        return processor_cls()

    def register(self, format_type: str, processor_cls: Type[DocumentProcessor]) -> None:
        self._registry[format_type.strip().lower()] = processor_cls


# ======================
# Discount Engine Logic
# ======================

class DiscountStrategy(ABC):
    """Product interface for discount strategies."""

    @abstractmethod
    def apply_discount(self, price: float, items_count: int) -> float:
        raise NotImplementedError


class RegularDiscount(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscount(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscount(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscount(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory(ABC):
    """Factory Method creator for discount strategies."""

    @abstractmethod
    def create_strategy(self, customer_type: str) -> DiscountStrategy:
        raise NotImplementedError


class RegistryDiscountStrategyFactory(DiscountStrategyFactory):
    """Scalable registry-based factory for discount strategies."""

    def __init__(self) -> None:
        self._registry: dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscount,
            "VIP": VipDiscount,
            "STUDENT": StudentDiscount,
        }
        self._default_strategy_cls: Type[DiscountStrategy] = DefaultDiscount

    def create_strategy(self, customer_type: str) -> DiscountStrategy:
        normalized: str = customer_type.strip().upper()
        strategy_cls = self._registry.get(normalized, self._default_strategy_cls)
        return strategy_cls()

    def register(self, customer_type: str, strategy_cls: Type[DiscountStrategy]) -> None:
        self._registry[customer_type.strip().upper()] = strategy_cls


# ==========================
# Refactored System Facade
# ==========================

class RefactoredSystem:
    def __init__(
        self,
        document_factory: DocumentProcessorFactory | None = None,
        discount_factory: DiscountStrategyFactory | None = None,
    ) -> None:
        self.version: str = "2.0 - Factory Method Refactor"
        self._document_factory: DocumentProcessorFactory = (
            document_factory if document_factory is not None else RegistryDocumentProcessorFactory()
        )
        self._discount_factory: DiscountStrategyFactory = (
            discount_factory if discount_factory is not None else RegistryDiscountStrategyFactory()
        )

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Refactored document processing using Factory Method."""
        if not data:
            return "Error: No data"

        processor: DocumentProcessor = self._document_factory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        """Refactored discount calculation using Factory Method."""
        strategy: DiscountStrategy = self._discount_factory.create_strategy(customer_type)
        return strategy.apply_discount(price, items_count)


# =================
# Execution Example
# =================

if __name__ == "__main__":
    system = RefactoredSystem()

    document_result = system.execute_document_process("pdf", "Research Report")
    discount_result = system.execute_ecommerce_discounts("VIP", 1200.0, 5)

    print(document_result)
    print(f"Final price: ${discount_result:.2f}")
