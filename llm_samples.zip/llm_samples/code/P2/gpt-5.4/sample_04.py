# Extracted automatically from sample_04.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Type


# ============================================================
# Document Processing Domain
# ============================================================

class DocumentProcessor(ABC):
    """Abstract product for document processing."""

    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into a target document format."""
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        escaped = data.replace('"', '\\"')
        return f'{{"data": "{escaped}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    """Factory Method implementation for document processors."""

    _registry: Dict[str, Type[DocumentProcessor]] = {
        "pdf": PdfDocumentProcessor,
        "json": JsonDocumentProcessor,
        "xml": XmlDocumentProcessor,
        "csv": CsvDocumentProcessor,
    }

    @classmethod
    def create_processor(cls, format_type: str) -> DocumentProcessor:
        key = format_type.strip().lower()
        processor_cls = cls._registry.get(key)

        if processor_cls is None:
            raise ValueError(f"Unsupported format: {format_type}")

        return processor_cls()

    @classmethod
    def register_processor(
        cls,
        format_type: str,
        processor_cls: Type[DocumentProcessor],
    ) -> None:
        cls._registry[format_type.strip().lower()] = processor_cls


# ============================================================
# Discount Domain
# ============================================================

class DiscountStrategy(ABC):
    """Abstract product for discount calculation."""

    @abstractmethod
    def apply(self, price: float, items_count: int) -> float:
        """Return the final price after applying the discount."""
        raise NotImplementedError


class RegularDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price * 0.80


class NoDiscount(DiscountStrategy):
    def apply(self, price: float, items_count: int) -> float:
        return price


class DiscountFactory:
    """Factory Method implementation for discount strategies."""

    _registry: Dict[str, Type[DiscountStrategy]] = {
        "REGULAR": RegularDiscount,
        "VIP": VipDiscount,
        "STUDENT": StudentDiscount,
    }

    @classmethod
    def create_discount(cls, customer_type: str) -> DiscountStrategy:
        key = customer_type.strip().upper()
        strategy_cls = cls._registry.get(key, NoDiscount)
        return strategy_cls()

    @classmethod
    def register_discount(
        cls,
        customer_type: str,
        strategy_cls: Type[DiscountStrategy],
    ) -> None:
        cls._registry[customer_type.strip().upper()] = strategy_cls


# ============================================================
# Application Service
# ============================================================

class RefactoredSystem:
    def __init__(self) -> None:
        self.version: str = "2.0 - Factory Method Refactor"

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Refactored document processing using Factory Method."""
        if not data:
            return "Error: No data"

        processor = DocumentProcessorFactory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        """Refactored discount engine using Factory Method."""
        strategy = DiscountFactory.create_discount(customer_type)
        return strategy.apply(price, items_count)


# ============================================================
# Execution simulation
# ============================================================

if __name__ == "__main__":
    system = RefactoredSystem()

    document_result = system.execute_document_process("pdf", "Research Report")
    print(document_result)

    discount_result = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"Final price: ${discount_result:.2f}")
