# Extracted automatically from sample_08.md by generate_samples.py (fenced:1)
# p1_factory_method_refactored.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Type


# =========================
# Document Processing Logic
# =========================

class DocumentProcessor(ABC):
    """Abstract product for document export behavior."""

    @abstractmethod
    def process(self, data: str) -> str:
        """Transform input data into a concrete document format."""
        raise NotImplementedError


class PDFDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JSONDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XMLDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CSVDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory:
    """Factory Method resolver for document processors."""

    _registry: Dict[str, Type[DocumentProcessor]] = {
        "pdf": PDFDocumentProcessor,
        "json": JSONDocumentProcessor,
        "xml": XMLDocumentProcessor,
        "csv": CSVDocumentProcessor,
    }

    @classmethod
    def create_processor(cls, format_type: str) -> DocumentProcessor:
        key = format_type.strip().lower()
        processor_cls = cls._registry.get(key)

        if processor_cls is None:
            raise ValueError(f"Unsupported format: {format_type}")

        return processor_cls()

    @classmethod
    def register_processor(
        cls,
        format_type: str,
        processor_cls: Type[DocumentProcessor],
    ) -> None:
        cls._registry[format_type.strip().lower()] = processor_cls


class DocumentService:
    """Application service for document processing."""

    def execute(self, format_type: str, data: str) -> str:
        if not data:
            return "Error: No data"

        processor = DocumentProcessorFactory.create_processor(format_type)
        return processor.process(data)


# ====================
# Discount Engine Logic
# ====================

class DiscountPolicy(ABC):
    """Abstract product for discount behavior."""

    @abstractmethod
    def calculate(self, price: float, items_count: int) -> float:
        """Return final price after discount."""
        raise NotImplementedError


class RegularDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VIPDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscountPolicy(DiscountPolicy):
    def calculate(self, price: float, items_count: int) -> float:
        return price


class DiscountPolicyFactory:
    """Factory Method resolver for discount policies."""

    _registry: Dict[str, Type[DiscountPolicy]] = {
        "REGULAR": RegularDiscountPolicy,
        "VIP": VIPDiscountPolicy,
        "STUDENT": StudentDiscountPolicy,
    }

    @classmethod
    def create_policy(cls, customer_type: str) -> DiscountPolicy:
        key = customer_type.strip().upper()
        policy_cls = cls._registry.get(key, DefaultDiscountPolicy)
        return policy_cls()

    @classmethod
    def register_policy(
        cls,
        customer_type: str,
        policy_cls: Type[DiscountPolicy],
    ) -> None:
        cls._registry[customer_type.strip().upper()] = policy_cls


class DiscountService:
    """Application service for discount calculation."""

    def execute(self, customer_type: str, price: float, items_count: int) -> float:
        policy = DiscountPolicyFactory.create_policy(customer_type)
        return policy.calculate(price, items_count)


# ======================================
# Facade preserving original entry points
# ======================================

class MonolithicSystem:
    """
    Compatibility facade that preserves the original public API,
    but delegates the targeted logic to Factory Method-based services.
    """

    def __init__(self) -> None:
        self.version: str = "2.0 - Factory Method Refactor"
        self._document_service = DocumentService()
        self._discount_service = DiscountService()

    def execute_document_process(self, format_type: str, data: str) -> str:
        return self._document_service.execute(format_type, data)

    def execute_ecommerce_discounts(
        self,
        customer_type: str,
        price: float,
        items_count: int,
    ) -> float:
        return self._discount_service.execute(customer_type, price, items_count)


# ====================
# Execution simulation
# ====================

if __name__ == "__main__":
    system = MonolithicSystem()

    doc_result = system.execute_document_process("pdf", "Research Report")
    print(doc_result)

    discount_result = system.execute_ecommerce_discounts("VIP", 1200, 5)
    print(f"{discount_result:.2f}")
