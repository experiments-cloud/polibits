# Extracted automatically from sample_02.md by generate_samples.py (fenced:1)
# p1_monolithic_refactored_factory_method.py

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Type


# ============================================================
# Document Processing - Factory Method
# ============================================================

class DocumentProcessor(ABC):
    """Abstract product for document processing."""

    @abstractmethod
    def process(self, data: str) -> str:
        """Transform/export the provided data into a target format."""
        raise NotImplementedError


class PdfDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<PDF Document>{data}</PDF Document>"


class JsonDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f'{{"data": "{data}"}}'


class XmlDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"<xml><data>{data}</data></xml>"


class CsvDocumentProcessor(DocumentProcessor):
    def process(self, data: str) -> str:
        return f"header,data\n1,{data}"


class DocumentProcessorFactory(ABC):
    """Abstract creator for document processors."""

    @abstractmethod
    def create_processor(self, format_type: str) -> DocumentProcessor:
        raise NotImplementedError


class RegistryDocumentProcessorFactory(DocumentProcessorFactory):
    """
    Concrete factory using a registry for scalability.
    New processors can be added by extending the registry.
    """

    def __init__(self) -> None:
        self._registry: Dict[str, Type[DocumentProcessor]] = {
            "pdf": PdfDocumentProcessor,
            "json": JsonDocumentProcessor,
            "xml": XmlDocumentProcessor,
            "csv": CsvDocumentProcessor,
        }

    def create_processor(self, format_type: str) -> DocumentProcessor:
        normalized_format: str = format_type.strip().lower()
        processor_cls = self._registry.get(normalized_format)

        if processor_cls is None:
            raise ValueError(f"Unsupported format: {format_type}")

        return processor_cls()

    def register(self, format_type: str, processor_cls: Type[DocumentProcessor]) -> None:
        """Optional extension point for future scalability."""
        self._registry[format_type.strip().lower()] = processor_cls


# ============================================================
# Discount Logic - Factory Method
# ============================================================

class DiscountStrategy(ABC):
    """Abstract product for discount calculation."""

    @abstractmethod
    def apply_discount(self, price: float, items_count: int) -> float:
        raise NotImplementedError


class RegularDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        if items_count > 10:
            return price * 0.95
        return price


class VipDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        if price > 1000:
            return price * 0.85
        return price * 0.90


class StudentDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        return price * 0.80


class DefaultDiscountStrategy(DiscountStrategy):
    def apply_discount(self, price: float, items_count: int) -> float:
        return price


class DiscountStrategyFactory(ABC):
    """Abstract creator for discount strategies."""

    @abstractmethod
    def create_strategy(self, customer_type: str) -> DiscountStrategy:
        raise NotImplementedError


class RegistryDiscountStrategyFactory(DiscountStrategyFactory):
    """
    Concrete factory using a registry for customer discount strategies.
    """

    def __init__(self) -> None:
        self._registry: Dict[str, Type[DiscountStrategy]] = {
            "REGULAR": RegularDiscountStrategy,
            "VIP": VipDiscountStrategy,
            "STUDENT": StudentDiscountStrategy,
        }

    def create_strategy(self, customer_type: str) -> DiscountStrategy:
        normalized_customer_type: str = customer_type.strip().upper()
        strategy_cls = self._registry.get(normalized_customer_type, DefaultDiscountStrategy)
        return strategy_cls()

    def register(self, customer_type: str, strategy_cls: Type[DiscountStrategy]) -> None:
        """Optional extension point for future scalability."""
        self._registry[customer_type.strip().upper()] = strategy_cls


# ============================================================
# Refactored Monolithic Facade
# ============================================================

class MonolithicSystem:
    """
    Preserves the original system entry points while delegating
    document processing and discount logic to Factory Method-based components.
    """

    def __init__(self) -> None:
        self.version: str = "2.0 - Refactored with Factory Method"
        self._document_factory: DocumentProcessorFactory = RegistryDocumentProcessorFactory()
        self._discount_factory: DiscountStrategyFactory = RegistryDiscountStrategyFactory()

    def execute_document_process(self, format_type: str, data: str) -> str:
        """Case 1: Document Processing via Factory Method."""
        if not data:
            return "Error: No data"

        processor: DocumentProcessor = self._document_factory.create_processor(format_type)
        return processor.process(data)

    def execute_ecommerce_discounts(self, customer_type: str, price: float, items_count: int) -> float:
        """Case 2: Discount Engine via Factory Method."""
        strategy: DiscountStrategy = self._discount_factory.create_strategy(customer_type)
        return strategy.apply_discount(price, items_count)


# ============================================================
# Execution simulation
# ============================================================

if __name__ == "__main__":
    system = MonolithicSystem()

    document_result = system.execute_document_process("pdf", "Research Report")
    print(document_result)

    discount_result = system.execute_ecommerce_discounts("VIP", 1200.0, 5)
    print(f"Final price: ${discount_result:.2f}")
